package com.lyfestyle.music.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import com.lyfestyle.music.data.Playlist
import com.lyfestyle.music.data.Track
import com.lyfestyle.music.ui.AppViewModel
import com.lyfestyle.music.ui.LocalStrings
import com.lyfestyle.music.ui.components.Artwork
import com.lyfestyle.music.ui.components.GlassIconButton
import com.lyfestyle.music.ui.components.NameInputDialog
import com.lyfestyle.music.ui.components.TrackPickerDialog
import com.lyfestyle.music.ui.components.TrackRow
import com.lyfestyle.music.ui.components.bounceClick
import com.lyfestyle.music.ui.components.liquidGlass
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LyfeColors

private const val FAV_ID = "__favorites__"

@Composable
fun PlaylistsScreen(vm: AppViewModel, bottomPad: Dp) {
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    val id = openId
    BackHandler(enabled = id != null) { openId = null }
    if (id == null) {
        PlaylistList(vm, bottomPad, onOpen = { openId = it })
    } else {
        PlaylistDetail(vm, id, bottomPad, onBack = { openId = null })
    }
}

@Composable
private fun PlaylistList(vm: AppViewModel, bottomPad: Dp, onOpen: (String) -> Unit) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val playlists by vm.store.playlists.collectAsState()
    val favs by vm.store.favorites.collectAsState()
    val trackMap by vm.trackMap.collectAsState()
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(s.playlists, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            GlassIconButton(Icons.Rounded.Add, s.newPlaylist, { creating = true }, size = 46.dp)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPad)) {
            item(key = FAV_ID) {
                val ids = favs.toList().filter { trackMap.containsKey(it) }
                PlaylistRow(
                    name = s.favorites,
                    count = ids.size,
                    tracks = ids.take(4).mapNotNull { trackMap[it] },
                    favorite = true,
                    onClick = { onOpen(FAV_ID) },
                    onPlay = {
                        val l = ids.mapNotNull { trackMap[it] }
                        if (l.isNotEmpty()) vm.player.play(l, 0)
                    },
                )
            }
            items(playlists, key = { it.id }) { p ->
                val l = p.trackIds.mapNotNull { trackMap[it] }
                PlaylistRow(
                    name = p.name,
                    count = l.size,
                    tracks = l.take(4),
                    favorite = false,
                    onClick = { onOpen(p.id) },
                    onPlay = { if (l.isNotEmpty()) vm.player.play(l, 0) },
                )
            }
            if (playlists.isEmpty()) {
                item(key = "empty") {
                    Text(
                        s.noPlaylists, color = LyfeColors.TextSecondary, fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                    )
                }
            }
        }
    }
    if (creating) {
        NameInputDialog(
            title = s.newPlaylist, label = s.playlistName, initial = "", confirmText = s.create,
            onConfirm = { name -> creating = false; onOpen(vm.store.createPlaylist(name)) },
            onDismiss = { creating = false },
        )
    }
}

@Composable
private fun PlaylistRow(
    name: String,
    count: Int,
    tracks: List<Track>,
    favorite: Boolean,
    onClick: () -> Unit,
    onPlay: () -> Unit,
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    Row(
        Modifier.fillMaxWidth().bounceClick(onClick, 0.98f).padding(horizontal = 18.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PlaylistCover(tracks, favorite, Modifier.size(68.dp))
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.tracksN(count), color = LyfeColors.TextSecondary, fontSize = 14.sp)
        }
        Box(
            Modifier.size(42.dp).background(accent.main.copy(alpha = 0.22f), CircleShape).bounceClick(onPlay, 0.88f),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.PlayArrow, s.play, tint = accent.soft, modifier = Modifier.size(26.dp)) }
    }
}

@Composable
private fun PlaylistCover(tracks: List<Track>, favorite: Boolean, modifier: Modifier) {
    val accent = LocalAccent.current
    if (favorite && tracks.isEmpty()) {
        Box(
            modifier.background(
                androidx.compose.ui.graphics.Brush.linearGradient(listOf(accent.main, accent.soft.copy(alpha = 0.6f))),
                RoundedCornerShape(16.dp),
            ),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Favorite, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
        return
    }
    when {
        tracks.isEmpty() -> Artwork(null, modifier, radius = 16.dp)
        tracks.size < 4 -> Artwork(tracks.first(), modifier, radius = 16.dp, decodeSize = 68.dp)
        else -> Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (r in 0..1) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (c in 0..1) {
                        Artwork(tracks[r * 2 + c], Modifier.weight(1f).fillMaxSize(), radius = 6.dp, decodeSize = 34.dp, border = false)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistDetail(vm: AppViewModel, id: String, bottomPad: Dp, onBack: () -> Unit) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val playlists by vm.store.playlists.collectAsState()
    val favs by vm.store.favorites.collectAsState()
    val trackMap by vm.trackMap.collectAsState()
    val allTracks by vm.tracks.collectAsState()
    val ps by vm.player.state.collectAsState()

    val isFav = id == FAV_ID
    val playlist = playlists.firstOrNull { it.id == id }
    if (!isFav && playlist == null) {
        androidx.compose.runtime.LaunchedEffect(Unit) { onBack() }
        return
    }
    val ids: List<Long> = if (isFav) favs.toList() else playlist!!.trackIds
    val tracks = ids.mapNotNull { trackMap[it] }
    val title = if (isFav) s.favorites else playlist!!.name

    var editing by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassIconButton(Icons.Rounded.ArrowBack, s.back, onBack, size = 44.dp)
            Text(
                title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            )
            if (!isFav) {
                GlassIconButton(Icons.Rounded.Edit, s.rename, { renaming = true }, size = 40.dp, iconSize = 20.dp)
                Spacer(Modifier.width(8.dp))
                GlassIconButton(Icons.Rounded.Delete, s.delete, { deleting = true }, size = 40.dp, iconSize = 20.dp)
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                Modifier.height(44.dp)
                    .background(accent.main, RoundedCornerShape(22.dp))
                    .bounceClick({ if (tracks.isNotEmpty()) vm.player.play(tracks, 0) }, 0.94f)
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(4.dp))
                Text(s.play, color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Row(
                Modifier.height(44.dp)
                    .liquidGlass(22.dp, glow = false)
                    .bounceClick({ if (tracks.isNotEmpty()) vm.player.shuffleAll(tracks) }, 0.94f)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Shuffle, null, tint = accent.soft, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text(s.shuffle, color = Color.White)
            }
            Spacer(Modifier.weight(1f))
            if (!isFav && tracks.size > 1) {
                GlassIconButton(
                    if (editing) Icons.Rounded.Check else Icons.Rounded.ArrowUpward,
                    s.edit, { editing = !editing }, size = 44.dp, iconSize = 22.dp,
                )
            }
        }
        if (!isFav) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp)
                    .bounceClick({ adding = true }, 0.97f),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Add, null, tint = accent.main, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(6.dp))
                Text(s.addSongs, color = accent.soft, fontSize = 16.sp)
            }
        }
        Text(
            s.tracksN(tracks.size), color = LyfeColors.TextMuted, fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp),
        )
        if (tracks.isEmpty()) {
            Text(
                s.emptyPlaylist, color = LyfeColors.TextSecondary, fontSize = 15.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp),
            )
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPad)) {
            itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
                TrackRow(
                    track = t,
                    current = ps.currentId == t.id,
                    favorite = t.id in favs,
                    onClick = { vm.player.play(tracks, i) },
                    modifier = Modifier.animateItem(),
                    trailing = {
                        if (editing && !isFav) {
                            MiniAction(Icons.Rounded.ArrowUpward, s.moveUp, enabled = i > 0) {
                                vm.store.moveTrack(id, ids.indexOf(t.id), ids.indexOf(t.id) - 1)
                            }
                            MiniAction(Icons.Rounded.ArrowDownward, s.moveDown, enabled = i < tracks.lastIndex) {
                                vm.store.moveTrack(id, ids.indexOf(t.id), ids.indexOf(t.id) + 1)
                            }
                            MiniAction(Icons.Rounded.Close, s.remove, enabled = true) { vm.store.removeTrack(id, t.id) }
                        } else if (isFav) {
                            MiniAction(Icons.Rounded.Close, s.remove, enabled = true) { vm.store.toggleFavorite(t.id) }
                        } else {
                            com.lyfestyle.music.ui.components.TrackMenuButton(t, t.id in favs)
                        }
                    },
                )
            }
        }
    }

    if (renaming && playlist != null) {
        NameInputDialog(
            title = s.rename, label = s.playlistName, initial = playlist.name, confirmText = s.save,
            onConfirm = { vm.store.renamePlaylist(id, it); renaming = false },
            onDismiss = { renaming = false },
        )
    }
    if (deleting && playlist != null) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            containerColor = LyfeColors.SurfaceHigh,
            title = { Text(s.deletePlaylistTitle, color = Color.White) },
            text = { Text(playlist.name, color = LyfeColors.TextSecondary) },
            confirmButton = {
                TextButton(onClick = { deleting = false; vm.store.deletePlaylist(id); onBack() }) {
                    Text(s.delete, color = Color(0xFFFF6B8A))
                }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text(s.cancel, color = LyfeColors.TextSecondary) } },
        )
    }
    if (adding && playlist != null) {
        val existing = playlist.trackIds.toSet()
        TrackPickerDialog(
            tracks = allTracks.filter { it.id !in existing },
            onDismiss = { adding = false },
            onConfirm = { picked -> vm.store.addTracks(id, picked); adding = false },
        )
    }
}

@Composable
private fun MiniAction(icon: ImageVector, desc: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).bounceClick(onClick, 0.85f, enabled = enabled),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = if (enabled) LocalAccent.current.soft else LyfeColors.TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(22.dp))
    }
}
