package com.lyfestyle.music.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyfestyle.music.ui.AppViewModel
import com.lyfestyle.music.ui.LocalStrings
import com.lyfestyle.music.ui.components.Artwork
import com.lyfestyle.music.ui.components.AvatarImage
import com.lyfestyle.music.ui.components.NameInputDialog
import com.lyfestyle.music.ui.components.bounceClick
import com.lyfestyle.music.ui.components.liquidGlass
import com.lyfestyle.music.ui.components.softCard
import com.lyfestyle.music.ui.components.subtitle
import com.lyfestyle.music.ui.theme.Accents
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import com.lyfestyle.music.ui.theme.LyfeColors

@Composable
fun ProfileScreen(vm: AppViewModel, bottomPad: Dp) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val settings = LocalSettings.current
    val tracks by vm.tracks.collectAsState()
    val playlists by vm.store.playlists.collectAsState()
    val counts by vm.store.playCounts.collectAsState()
    val listenMs by vm.store.listenMs.collectAsState()
    val trackMap by vm.trackMap.collectAsState()
    var editName by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setAvatar(uri)
    }

    val top = remember(counts, trackMap) {
        counts.entries.sortedByDescending { it.value }
            .mapNotNull { e -> trackMap[e.key]?.let { it to e.value } }
            .take(8)
    }
    val totalPlays = counts.values.sum()

    LazyColumn(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { Text(s.profileTitle, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp)) }

        // Аватар и имя
        item {
            Row(
                Modifier.fillMaxWidth().softCard(24.dp).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(92.dp).liquidGlass(46.dp).bounceClick(
                        { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, 0.94f
                    ),
                    contentAlignment = Alignment.Center,
                ) { AvatarImage(settings.avatarVersion, 84.dp) }
                Column(Modifier.weight(1f).padding(start = 16.dp)) {
                    Row(Modifier.bounceClick({ editName = true }, 0.97f), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            settings.userName.ifBlank { s.defaultUserName },
                            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                        )
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.Rounded.Edit, s.editName, tint = accent.soft, modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        s.changePhoto, color = accent.soft, fontSize = 14.sp,
                        modifier = Modifier.bounceClick(
                            { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, 0.95f
                        ),
                    )
                }
            }
        }

        // Статистика
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(s.songsStat, tracks.size.toString(), Modifier.weight(1f))
                    StatCard(s.playlistsStat, playlists.size.toString(), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(s.playsStat, totalPlays.toString(), Modifier.weight(1f))
                    StatCard(s.listenTimeStat, s.listenTime(listenMs), Modifier.weight(1f))
                }
            }
        }

        // Топ треков
        item { Text(s.topTracks, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
        if (top.isEmpty()) {
            item { Text(s.noStatsYet, color = LyfeColors.TextSecondary, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp)) }
        } else {
            item {
                Column(Modifier.fillMaxWidth().softCard(22.dp).padding(vertical = 6.dp)) {
                    val list = top.map { it.first }
                    top.forEachIndexed { i, (t, n) ->
                        Row(
                            Modifier.fillMaxWidth().bounceClick({ vm.player.play(list, i) }, 0.98f)
                                .padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${i + 1}", color = accent.soft, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(26.dp))
                            Artwork(t, Modifier.size(46.dp), radius = 12.dp, decodeSize = 46.dp)
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(t.title, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(t.subtitle(s), color = LyfeColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(s.playsN(n), color = LyfeColors.TextMuted, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Настройки
        item { Text(s.appearance, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
        item {
            Column(Modifier.fillMaxWidth().softCard(22.dp).padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                // Язык
                Column {
                    Text(s.language, color = Color.White, fontSize = 16.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LangChip(s.russian, settings.language == "ru") { vm.store.updateSettings { it.copy(language = "ru") } }
                        LangChip(s.english, settings.language == "en") { vm.store.updateSettings { it.copy(language = "en") } }
                    }
                }
                SettingSwitch(s.liquidGlass, s.liquidGlassDesc, settings.liquidGlass) { v ->
                    vm.store.updateSettings { it.copy(liquidGlass = v) }
                }
                if (settings.liquidGlass) {
                    Column {
                        Text(s.glassIntensity, color = Color.White, fontSize = 16.sp)
                        Slider(
                            value = settings.glassIntensity,
                            onValueChange = { v -> vm.store.updateSettings { it.copy(glassIntensity = v) } },
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = accent.soft,
                                activeTrackColor = accent.main,
                                inactiveTrackColor = Color.White.copy(alpha = 0.12f),
                            ),
                        )
                    }
                }
                Column {
                    Text(s.accentColor, color = Color.White, fontSize = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Accents.forEachIndexed { i, a ->
                            val sel = i == settings.accentIndex
                            Box(
                                Modifier
                                    .size(38.dp)
                                    .background(a.main, CircleShape)
                                    .then(if (sel) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                                    .bounceClick({ vm.store.updateSettings { it.copy(accentIndex = i) } }, 0.88f)
                            )
                        }
                    }
                }
                SettingSwitch(s.dynamicBg, s.dynamicBgDesc, settings.dynamicBackground) { v ->
                    vm.store.updateSettings { it.copy(dynamicBackground = v) }
                }
            }
        }
        item {
            Text(
                "LyfeStyle Music · " + s.versionLabel,
                color = LyfeColors.TextMuted, fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }

    if (editName) {
        NameInputDialog(
            title = s.editName, label = s.editName, initial = settings.userName, confirmText = s.save,
            onConfirm = { n -> vm.store.updateSettings { it.copy(userName = n) }; editName = false },
            onDismiss = { editName = false },
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Column(modifier.softCard(20.dp).padding(16.dp)) {
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Text(label, color = LyfeColors.TextSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun LangChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier
            .height(40.dp)
            .background(if (selected) accent.main else Color.White.copy(alpha = 0.06f), shape)
            .border(1.dp, if (selected) accent.soft.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.10f), shape)
            .bounceClick(onClick, 0.94f)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color.White, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal) }
}

@Composable
private fun SettingSwitch(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val accent = LocalAccent.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp)
            Text(desc, color = LyfeColors.TextSecondary, fontSize = 13.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent.main,
                uncheckedThumbColor = LyfeColors.TextSecondary,
                uncheckedTrackColor = Color.White.copy(alpha = 0.10f),
                uncheckedBorderColor = Color.White.copy(alpha = 0.15f),
            ),
        )
    }
}
