package com.lyfestyle.music.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lyfestyle.music.LyfeApp
import com.lyfestyle.music.data.MusicRepository
import com.lyfestyle.music.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val lyfe = app as LyfeApp
    val store = lyfe.store
    val player = lyfe.player
    private val repo = MusicRepository(app)

    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    val trackMap: StateFlow<Map<Long, Track>> =
        _tracks.map { l -> l.associateBy { it.id } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    fun refresh() {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            try {
                _tracks.value = withContext(Dispatchers.IO) { repo.loadAll() }
            } finally {
                _loading.value = false
            }
        }
    }

    fun setAvatar(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val cr = app.contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var s = 1
                while (bounds.outWidth / (s * 2) >= 512 && bounds.outHeight / (s * 2) >= 512) s *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = s }
                val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@launch
                val side = min(bmp.width, bmp.height)
                val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                File(app.filesDir, "avatar.jpg").outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                withContext(Dispatchers.Main) {
                    store.updateSettings { it.copy(avatarVersion = System.currentTimeMillis()) }
                }
            } catch (_: Throwable) {
            }
        }
    }
}
