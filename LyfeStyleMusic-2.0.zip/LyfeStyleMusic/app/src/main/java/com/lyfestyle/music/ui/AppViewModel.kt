package com.lyfestyle.music.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lyfestyle.music.LyfeApp
import com.lyfestyle.music.data.CoverStore
import com.lyfestyle.music.data.MusicRepository
import com.lyfestyle.music.data.Track
import com.lyfestyle.music.ui.components.ArtworkLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val lyfe = app as LyfeApp
    val store = lyfe.store
    val player = lyfe.player
    private val repo = MusicRepository(app)

    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    val trackMap: StateFlow<Map<Long, Track>> =
        _tracks.map { l -> l.associateBy { it.id } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    fun refresh() {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            try {
                _tracks.value = withContext(Dispatchers.IO) { repo.loadAll() }
            } finally {
                _loading.value = false
            }
        }
    }

    /** Квадратная обрезка по центру с уменьшением до ~target px. */
    private fun decodeSquare(uri: Uri, target: Int): Bitmap? {
        val cr = getApplication<Application>().contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (bounds.outWidth / (s * 2) >= target && bounds.outHeight / (s * 2) >= target) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val side = min(bmp.width, bmp.height)
        return Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
    }

    fun setAvatar(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val sq = decodeSquare(uri, 512) ?: return@launch
                File(app.filesDir, "avatar.jpg").outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                withContext(Dispatchers.Main) {
                    store.updateSettings { it.copy(avatarVersion = System.currentTimeMillis()) }
                }
            } catch (_: Throwable) {
            }
        }
    }

    fun setCover(track: Track, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val sq = decodeSquare(uri, 1024) ?: return@launch
                val f = CoverStore.file(getApplication<Application>(), track.id)
                f.parentFile?.mkdirs()
                f.outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                withContext(Dispatchers.Main) { ArtworkLoader.invalidate(track.id) }
            } catch (_: Throwable) {
            }
        }
    }

    fun resetCover(track: Track) {
        viewModelScope.launch(Dispatchers.IO) {
            CoverStore.file(getApplication<Application>(), track.id).delete()
            withContext(Dispatchers.Main) { ArtworkLoader.invalidate(track.id) }
        }
    }
}
