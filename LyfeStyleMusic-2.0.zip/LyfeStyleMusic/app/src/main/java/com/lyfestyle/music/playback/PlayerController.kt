package com.lyfestyle.music.playback

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.lyfestyle.music.data.LocalStore
import com.lyfestyle.music.data.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToInt

data class PlayerState(
    val connected: Boolean = false,
    val currentId: Long? = null,
    val currentIndex: Int = -1,
    val queue: List<Long> = emptyList(),
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val sleepEndsAt: Long = 0L,
    /** +1 — переход вперёд, -1 — назад (для анимации смены обложки). */
    val direction: Int = 1,
)

fun Track.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist.ifBlank { null })
                .setAlbumTitle(album.ifBlank { null })
                .setArtworkUri(artworkUri)
                .build()
        )
        .build()

/** Мост между UI и службой воспроизведения (через MediaController). */
class PlayerController(private val context: Context, private val store: LocalStore) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var controller: MediaController? = null
    private val pending = ArrayList<(MediaController) -> Unit>()
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    private val _volume = MutableStateFlow(readVolume())
    val volume: StateFlow<Float> = _volume.asStateFlow()

    private var uiActive = false
    private var errorCount = 0

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(events.contains(Player.EVENT_TIMELINE_CHANGED))
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem?.mediaId?.toLongOrNull()?.let { store.recordPlay(it) }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) errorCount = 0
        }

        override fun onPlayerError(error: PlaybackException) {
            val c = controller ?: return
            errorCount++
            if (errorCount < 5 && c.hasNextMediaItem()) {
                c.seekToNextMediaItem()
                c.prepare()
                c.play()
            }
        }
    }

    fun connect() {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = try {
                future.get()
            } catch (e: Exception) {
                return@addListener
            }
            controller = c
            c.addListener(listener)
            sync(true)
            pending.forEach { it(c) }
            pending.clear()
            startTicker()
        }, ContextCompat.getMainExecutor(context))
    }

    fun setUiActive(active: Boolean) {
        uiActive = active
        if (active) {
            sync(true)
            _volume.value = readVolume()
        }
    }

    private fun whenReady(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending.add(block)
    }

    private fun sync(rebuildQueue: Boolean) {
        val c = controller ?: return
        val old = _state.value
        val count = c.mediaItemCount
        val queue = if (rebuildQueue || !old.connected || old.queue.size != count) {
            List(count) { c.getMediaItemAt(it).mediaId.toLongOrNull() ?: -1L }
        } else old.queue
        val idx = if (count == 0) -1 else c.currentMediaItemIndex
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        val dir = if (id != old.currentId) (if (idx >= old.currentIndex) 1 else -1) else old.direction
        val dur = c.duration
        _state.value = PlayerState(
            connected = true,
            currentId = id,
            currentIndex = idx,
            queue = queue,
            isPlaying = c.isPlaying,
            isBuffering = c.playbackState == Player.STATE_BUFFERING,
            durationMs = if (dur != C.TIME_UNSET && dur > 0) dur else 0L,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            sleepEndsAt = old.sleepEndsAt,
            direction = dir,
        )
        _position.value = c.currentPosition.coerceAtLeast(0L)
    }

    private fun startTicker() {
        scope.launch {
            var pendingMs = 0L
            while (isActive) {
                val c = controller
                var step = 1000L
                if (c != null) {
                    val playing = c.isPlaying
                    if (playing) {
                        step = if (uiActive) 250L else 1000L
                        pendingMs += step
                        if (pendingMs >= 10_000L) {
                            store.addListenMs(pendingMs)
                            pendingMs = 0L
                        }
                    } else if (pendingMs > 0L) {
                        store.addListenMs(pendingMs)
                        pendingMs = 0L
                    }
                    if (uiActive) {
                        _position.value = c.currentPosition.coerceAtLeast(0L)
                        val v = readVolume()
                        if (v != _volume.value) _volume.value = v
                    }
                    val end = _state.value.sleepEndsAt
                    if (end > 0L && System.currentTimeMillis() >= end) {
                        c.pause()
                        _state.update { it.copy(sleepEndsAt = 0L) }
                    }
                }
                delay(step)
            }
        }
    }

    // ---------- Команды ----------

    fun play(tracks: List<Track>, startIndex: Int, shuffle: Boolean = false) {
        if (tracks.isEmpty()) return
        var list = tracks
        var start = startIndex.coerceIn(0, tracks.lastIndex)
        if (tracks.size > MAX_QUEUE) {
            // Ограничиваем размер очереди, чтобы не превысить лимит Binder.
            val from = (start - MAX_QUEUE / 2).coerceAtLeast(0)
            val to = min(tracks.size, from + MAX_QUEUE)
            list = tracks.subList(from, to)
            start -= from
        }
        val items = list.map { it.toMediaItem() }
        whenReady { c ->
            if (shuffle) c.shuffleModeEnabled = true
            c.setMediaItems(items, start, 0L)
            c.prepare()
            c.play()
        }
    }

    fun shuffleAll(tracks: List<Track>) = play(tracks.shuffled(), 0, shuffle = true)

    fun togglePlay() = whenReady { c ->
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun next() = whenReady { it.seekToNext() }
    fun previous() = whenReady { it.seekToPrevious() }

    fun seekTo(ms: Long) = whenReady {
        it.seekTo(ms.coerceAtLeast(0L))
        _position.value = ms.coerceAtLeast(0L)
    }

    fun seekToQueueIndex(index: Int) = whenReady {
        if (index in 0 until it.mediaItemCount) {
            it.seekTo(index, 0L)
            it.play()
        }
    }

    fun toggleShuffle() = whenReady { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() = whenReady {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun playNext(track: Track) {
        val item = track.toMediaItem()
        whenReady { c ->
            if (c.mediaItemCount == 0) {
                c.setMediaItem(item)
                c.prepare()
                c.play()
            } else {
                c.addMediaItem(c.currentMediaItemIndex + 1, item)
            }
        }
    }

    fun addToQueue(track: Track) {
        val item = track.toMediaItem()
        whenReady { c ->
            if (c.mediaItemCount == 0) {
                c.setMediaItem(item)
                c.prepare()
                c.play()
            } else {
                c.addMediaItem(item)
            }
        }
    }

    fun removeFromQueue(index: Int) = whenReady {
        if (index in 0 until it.mediaItemCount) it.removeMediaItem(index)
    }

    fun moveInQueue(from: Int, to: Int) = whenReady {
        if (from in 0 until it.mediaItemCount && to in 0 until it.mediaItemCount) it.moveMediaItem(from, to)
    }

    fun setVolume(fraction: Float) {
        try {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (fraction.coerceIn(0f, 1f) * max).roundToInt(), 0)
        } catch (_: Exception) {
        }
        _volume.value = fraction.coerceIn(0f, 1f)
    }

    /** minutes = 0 — выключить таймер сна. */
    fun setSleepTimer(minutes: Int) {
        val end = if (minutes > 0) System.currentTimeMillis() + minutes * 60_000L else 0L
        _state.update { it.copy(sleepEndsAt = end) }
    }

    private fun readVolume(): Float {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    companion object {
        private const val MAX_QUEUE = 400
    }
}
