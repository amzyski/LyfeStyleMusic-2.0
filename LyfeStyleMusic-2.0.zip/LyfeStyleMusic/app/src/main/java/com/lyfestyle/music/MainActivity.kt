package com.lyfestyle.music

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lyfestyle.music.ui.AppRoot
import com.lyfestyle.music.ui.AppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppViewModel = viewModel()
            AppRoot(vm)
        }
    }

    override fun onStart() {
        super.onStart()
        (application as LyfeApp).player.setUiActive(true)
    }

    override fun onStop() {
        (application as LyfeApp).player.setUiActive(false)
        super.onStop()
    }
}
