package com.lyfestyle.music.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyfestyle.music.data.Track
import com.lyfestyle.music.ui.AppViewModel
import com.lyfestyle.music.ui.LocalStrings
import com.lyfestyle.music.ui.components.SearchField
import com.lyfestyle.music.ui.components.TrackRow
import com.lyfestyle.music.ui.components.normalize
import com.lyfestyle.music.ui.theme.LyfeColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SearchScreen(vm: AppViewModel, bottomPad: Dp) {
    val s = LocalStrings.current
    val tracks by vm.tracks.collectAsState()
    val ps by vm.player.state.collectAsState()
    val favs by vm.store.favorites.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }

    // Предвычисленный индекс: название + исполнитель + альбом
    val index = remember(tracks) { tracks.map { it to normalize("${it.title} ${it.artist} ${it.album}") } }
    val results by produceState(initialValue = emptyList<Track>(), index, query) {
        val q = normalize(query).trim()
        value = if (q.isEmpty()) emptyList() else withContext(Dispatchers.Default) {
            val tokens = q.split(' ').filter { it.isNotEmpty() }
            index.filter { (_, text) -> tokens.all { text.contains(it) } }.map { it.first }
        }
    }

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars).imePadding()) {
        Text(
            s.search, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 12.dp),
        )
        SearchField(query, { query = it }, s.searchHint, Modifier.padding(horizontal = 16.dp))
        Box(Modifier.fillMaxSize().padding(top = 8.dp)) {
            when {
                query.isBlank() -> Hint(s.searchEmptyHint)
                results.isEmpty() -> Hint(s.nothingFound)
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPad)) {
                    itemsIndexed(results, key = { _, t -> t.id }) { i, t ->
                        TrackRow(
                            track = t,
                            current = ps.currentId == t.id,
                            favorite = t.id in favs,
                            onClick = { vm.player.play(results, i) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Column(
        Modifier.fillMaxSize().padding(bottom = 120.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(text, color = LyfeColors.TextSecondary, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp))
    }
}
