package com.lyfestyle.music.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

class MusicRepository(private val context: Context) {

    /** Читает все аудиофайлы устройства из MediaStore. Вызывать из фонового потока. */
    fun loadAll(): List<Track> {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
        )
        val selection = "${MediaStore.Audio.Media.DURATION} >= ?"
        val args = arrayOf("15000")
        val result = ArrayList<Track>()
        try {
            context.contentResolver.query(collection, projection, selection, args, null)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val iRing = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_RINGTONE)
                val iNotif = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_NOTIFICATION)
                val iAlarm = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_ALARM)
                while (c.moveToNext()) {
                    if (c.getInt(iRing) != 0 || c.getInt(iNotif) != 0 || c.getInt(iAlarm) != 0) continue
                    val id = c.getLong(iId)
                    val rawTitle = c.getString(iTitle).orEmpty()
                    val title = rawTitle.ifBlank {
                        c.getString(iName).orEmpty().substringBeforeLast('.')
                    }
                    result.add(
                        Track(
                            id = id,
                            title = title,
                            artist = clean(c.getString(iArtist)),
                            album = clean(c.getString(iAlbum)),
                            albumId = c.getLong(iAlbumId),
                            durationMs = c.getLong(iDur),
                            uri = ContentUris.withAppendedId(collection, id),
                            dateAdded = c.getLong(iAdded),
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
            return emptyList()
        }
        return result.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
    }

    private fun clean(s: String?): String =
        if (s == null || s == MediaStore.UNKNOWN_STRING || s == "<unknown>") "" else s.trim()
}
