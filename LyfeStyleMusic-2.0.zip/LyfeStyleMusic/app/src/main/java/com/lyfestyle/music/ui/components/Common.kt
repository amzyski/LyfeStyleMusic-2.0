package com.lyfestyle.music.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lyfestyle.music.R
import com.lyfestyle.music.data.Playlist
import com.lyfestyle.music.data.Track
import com.lyfestyle.music.ui.LocalStrings
import com.lyfestyle.music.ui.Strings
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LyfeColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

// ---------- Утилиты ----------

fun fmtTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun normalize(s: String): String = s.lowercase().replace('ё', 'е')

fun Track.subtitle(s: Strings): String {
    val parts = listOfNotNull(artist.takeIf { it.isNotBlank() }, album.takeIf { it.isNotBlank() })
    return if (parts.isEmpty()) s.unknownArtist else parts.joinToString(" · ")
}

fun Track.artistLabel(s: Strings): String = artist.ifBlank { s.unknownArtist }

fun Modifier.softCard(radius: Dp = 20.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .background(Color.White.copy(alpha = 0.05f), shape)
        .border(1.dp, Color.White.copy(alpha = 0.08f), shape)
}

// ---------- Действия над треками ----------

class TrackActions(
    val playNext: (Track) -> Unit,
    val addToQueue: (Track) -> Unit,
    val addToPlaylist: (Track) -> Unit,
    val toggleFavorite: (Track) -> Unit,
)

val LocalTrackActions = staticCompositionLocalOf<TrackActions> { error("TrackActions not provided") }

// ---------- Строка трека ----------

@Composable
fun TrackRow(
    track: Track,
    current: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: @Composable RowScope.() -> Unit = { TrackMenuButton(track, favorite) },
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick(onClick, 0.98f)
            .padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(track, Modifier.size(60.dp), radius = 16.dp, decodeSize = 60.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(
                track.title,
                color = if (current) accent.soft else Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                track.subtitle(s),
                color = LyfeColors.TextSecondary,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Text(fmtTime(track.durationMs), color = LyfeColors.TextMuted, fontSize = 14.sp)
        trailing()
    }
}

@Composable
fun TrackMenuButton(track: Track, favorite: Boolean) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val actions = LocalTrackActions.current
    var open by remember { mutableStateOf(false) }
    Box {
        Box(Modifier.size(44.dp).bounceClick({ open = true }, 0.85f), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.MoreVert, s.more, tint = accent.main)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text(s.menuPlayNext) },
                leadingIcon = { Icon(Icons.Rounded.PlaylistPlay, null) },
                onClick = { open = false; actions.playNext(track) },
            )
            DropdownMenuItem(
                text = { Text(s.menuAddQueue) },
                leadingIcon = { Icon(Icons.Rounded.QueueMusic, null) },
                onClick = { open = false; actions.addToQueue(track) },
            )
            DropdownMenuItem(
                text = { Text(s.menuAddPlaylist) },
                leadingIcon = { Icon(Icons.Rounded.PlaylistAdd, null) },
                onClick = { open = false; actions.addToPlaylist(track) },
            )
            DropdownMenuItem(
                text = { Text(if (favorite) s.menuUnfav else s.menuFav) },
                leadingIcon = { Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null) },
                onClick = { open = false; actions.toggleFavorite(track) },
            )
        }
    }
}

@Composable
fun TrackInfoDialog(track: Track, onDismiss: () -> Unit) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LyfeColors.SurfaceHigh,
        title = { Text(s.menuInfo, color = Color.White) },
        text = {
            Column {
                InfoLine(s.title, track.title)
                InfoLine(s.artist, track.artistLabel(s))
                InfoLine(s.album, track.album.ifBlank { s.unknownAlbum })
                InfoLine(s.duration, fmtTime(track.durationMs))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(s.close, color = accent.soft) } },
    )
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 5.dp)) {
        Text(label, color = LyfeColors.TextMuted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 16.sp)
    }
}

// ---------- Полоса прогресса / громкости ----------

@Composable
fun SeekBar(
    fraction: Float,
    onChange: (Float) -> Unit,
    onFinished: (Float) -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color,
    trackColor: Color,
    thickness: Dp = 6.dp,
    showThumb: Boolean = true,
) {
    val change by rememberUpdatedState(onChange)
    val finished by rememberUpdatedState(onFinished)
    Canvas(
        modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val f = (o.x / size.width).coerceIn(0f, 1f)
                    change(f)
                    finished(f)
                }
            }
            .pointerInput(Unit) {
                var last = 0f
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        last = (o.x / size.width).coerceIn(0f, 1f)
                        change(last)
                    },
                    onDragEnd = { finished(last) },
                    onDragCancel = { finished(last) },
                    onHorizontalDrag = { c, _ ->
                        c.consume()
                        last = (c.position.x / size.width).coerceIn(0f, 1f)
                        change(last)
                    },
                )
            }
    ) {
        val th = thickness.toPx()
        val cy = size.height / 2f
        val w = size.width
        val f = fraction.coerceIn(0f, 1f)
        drawLine(trackColor, Offset(th / 2, cy), Offset(w - th / 2, cy), th, StrokeCap.Round)
        if (f > 0f) {
            drawLine(activeColor, Offset(th / 2, cy), Offset(max(th / 2, w * f), cy), th, StrokeCap.Round)
        }
        if (showThumb) {
            val r = 7.dp.toPx()
            val x = (w * f).coerceIn(r, w - r)
            drawCircle(Color.White.copy(alpha = 0.95f), r, Offset(x, cy))
            drawCircle(activeColor, r * 0.55f, Offset(x, cy))
        }
    }
}

// ---------- Поле поиска ----------

@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    backdrop: Boolean = true,
    focusManager: FocusManager = LocalFocusManager.current,
) {
    val accent = LocalAccent.current
    Row(
        modifier
            .fillMaxWidth()
            .height(52.dp)
            .liquidGlass(26.dp, strength = 0.8f, backdrop = backdrop, glow = false)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, tint = accent.soft, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
            cursorBrush = SolidColor(accent.main),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(hint, color = LyfeColors.TextMuted, fontSize = 17.sp, maxLines = 1)
                    inner()
                }
            },
        )
        if (value.isNotEmpty()) {
            Box(Modifier.size(32.dp).bounceClick({ onValueChange("") }, 0.85f), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Close, null, tint = LyfeColors.TextSecondary, modifier = Modifier.size(20.dp))
            }
        }
    }
}

// ---------- Аватар ----------

@Composable
fun AvatarImage(version: Long, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, version) {
        value = withContext(Dispatchers.IO) {
            val f = File(ctx.filesDir, "avatar.jpg")
            if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
        }
    }
    Box(modifier.size(size).clip(CircleShape), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Image(painterResource(R.drawable.ic_brand), null, Modifier.fillMaxSize(0.78f))
        }
    }
}

// ---------- Диалоги ----------

@Composable
fun NameInputDialog(
    title: String,
    label: String,
    initial: String,
    confirmText: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LyfeColors.SurfaceHigh,
        title = { Text(title, color = Color.White) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(40) },
                singleLine = true,
                label = { Text(label) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = accent.main,
                    unfocusedBorderColor = LyfeColors.TextMuted,
                    cursorColor = accent.main,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = accent.soft,
                    unfocusedLabelColor = LyfeColors.TextSecondary,
                ),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text.trim()) }, enabled = text.isNotBlank()) {
                Text(confirmText, color = accent.soft)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(s.cancel, color = LyfeColors.TextSecondary) } },
    )
}

@Composable
fun PlaylistPickerDialog(
    playlists: List<Playlist>,
    onPick: (String) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NameInputDialog(
            title = s.newPlaylist,
            label = s.playlistName,
            initial = "",
            confirmText = s.create,
            onConfirm = { onCreate(it) },
            onDismiss = { creating = false },
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LyfeColors.SurfaceHigh,
        title = { Text(s.choosePlaylist, color = Color.White) },
        text = {
            if (playlists.isEmpty()) {
                Text(s.noPlaylists, color = LyfeColors.TextSecondary)
            } else {
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    items(playlists, key = { it.id }) { p ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onPick(p.id) }
                                .padding(vertical = 12.dp)
                        ) {
                            Text(p.name, color = Color.White, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.tracksN(p.trackIds.size), color = LyfeColors.TextSecondary, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { creating = true }) { Text("+ " + s.newPlaylist, color = accent.soft) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(s.cancel, color = LyfeColors.TextSecondary) } },
    )
}

/** Полноэкранный выбор нескольких песен из библиотеки. */
@Composable
fun TrackPickerDialog(
    tracks: List<Track>,
    onDismiss: () -> Unit,
    onConfirm: (List<Long>) -> Unit,
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    val filtered = remember(tracks, query) {
        val q = normalize(query).trim()
        if (q.isEmpty()) tracks else tracks.filter { normalize("${it.title} ${it.artist} ${it.album}").contains(q) }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = LyfeColors.Bg) {
            Column(Modifier.systemBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(44.dp).bounceClick(onDismiss, 0.88f), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, s.close, tint = Color.White)
                    }
                    Text(s.addSongs, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onConfirm(selected.toList()) }, enabled = selected.isNotEmpty()) {
                        Text(s.selectedN(selected.size), color = if (selected.isNotEmpty()) accent.soft else LyfeColors.TextMuted)
                    }
                }
                SearchField(query, { query = it }, s.searchHint, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), backdrop = false)
                if (tracks.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(s.allSongsAdded, color = LyfeColors.TextSecondary)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(filtered, key = { it.id }) { t ->
                            val checked = t.id in selected
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { selected = if (checked) selected - t.id else selected + t.id }
                                    .padding(horizontal = 16.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Artwork(t, Modifier.size(48.dp), radius = 12.dp, decodeSize = 48.dp)
                                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                    Text(t.title, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(t.subtitle(s), color = LyfeColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { selected = if (checked) selected - t.id else selected + t.id },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = accent.main,
                                        uncheckedColor = LyfeColors.TextMuted,
                                        checkmarkColor = Color.White,
                                    ),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Фон ----------

@Composable
fun LyfeBackground(colorA: Color, colorB: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        drawRect(LyfeColors.Bg)
        drawRect(
            Brush.radialGradient(
                listOf(colorA.copy(alpha = 0.55f), Color.Transparent),
                center = Offset(size.width * 0.1f, size.height * 0.02f),
                radius = size.width * 1.15f,
            )
        )
        drawRect(
            Brush.radialGradient(
                listOf(colorB.copy(alpha = 0.34f), Color.Transparent),
                center = Offset(size.width, size.height * 0.98f),
                radius = size.width * 1.0f,
            )
        )
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, LyfeColors.Bg.copy(alpha = 0.55f)),
                startY = size.height * 0.3f,
                endY = size.height,
            )
        )
    }
}
