package com.lyfestyle.music.ui

import androidx.compose.runtime.staticCompositionLocalOf

/** Локализация RU/EN, переключается в приложении мгновенно. */
class Strings(private val ru: Boolean) {
    private fun t(r: String, e: String) = if (ru) r else e

    val library: String get() = t("Библиотека", "Library")
    val playlists: String get() = t("Плейлисты", "Playlists")
    val profile: String get() = t("Профиль", "Profile")
    val search: String get() = t("Поиск", "Search")

    fun songsCount(n: Int): String = t("Песен: $n", "Songs: $n")
    fun tracksN(n: Int): String = t("Песен: $n", "$n songs")
    fun playsN(n: Int): String = t("$n прослушиваний", "$n plays")
    fun selectedN(n: Int): String = t("Добавить ($n)", "Add ($n)")
    fun minutesN(n: Int): String = t("$n мин", "$n min")

    val refresh: String get() = t("Обновить", "Refresh")
    val shuffle: String get() = t("Перемешать", "Shuffle")
    val more: String get() = t("Ещё", "More")
    val back: String get() = t("Назад", "Back")
    val close: String get() = t("Закрыть", "Close")
    val cancel: String get() = t("Отмена", "Cancel")
    val save: String get() = t("Сохранить", "Save")
    val create: String get() = t("Создать", "Create")
    val delete: String get() = t("Удалить", "Delete")
    val rename: String get() = t("Переименовать", "Rename")
    val remove: String get() = t("Убрать", "Remove")
    val done: String get() = t("Готово", "Done")
    val play: String get() = t("Играть", "Play")

    val noMusic: String get() = t("Музыка не найдена", "No music found")
    val noMusicHint: String get() = t(
        "Добавьте аудиофайлы на устройство и нажмите «Обновить».",
        "Add audio files to your device and tap Refresh."
    )
    val permTitle: String get() = t("Доступ к музыке", "Music access")
    val permBody: String get() = t(
        "LyfeStyle Music воспроизводит только файлы, которые уже есть на вашем устройстве. Разрешите доступ к аудио, чтобы показать вашу библиотеку.",
        "LyfeStyle Music plays only the files already on your device. Allow audio access to show your library."
    )
    val permAllow: String get() = t("Разрешить доступ", "Allow access")
    val permSettings: String get() = t("Открыть настройки", "Open settings")

    val unknownArtist: String get() = t("Неизвестный исполнитель", "Unknown artist")
    val unknownAlbum: String get() = t("Неизвестный альбом", "Unknown album")

    val menuPlayNext: String get() = t("Играть следующим", "Play next")
    val menuAddQueue: String get() = t("Добавить в очередь", "Add to queue")
    val menuAddPlaylist: String get() = t("Добавить в плейлист", "Add to playlist")
    val menuFav: String get() = t("В избранное", "Add to favorites")
    val menuUnfav: String get() = t("Убрать из избранного", "Remove from favorites")
    val menuInfo: String get() = t("О треке", "Track info")
    val changeCover: String get() = t("Сменить обложку", "Change cover")
    val resetCover: String get() = t("Сбросить обложку", "Reset cover")
    val coverUpdated: String get() = t("Обложка обновлена", "Cover updated")
    val addedToQueue: String get() = t("Добавлено в очередь", "Added to queue")
    val playNextDone: String get() = t("Будет играть следующим", "Will play next")
    fun addedToPlaylist(name: String): String = t("Добавлено в «$name»", "Added to \"$name\"")

    val searchHint: String get() = t("Название, исполнитель или альбом", "Title, artist or album")
    val searchEmptyHint: String get() = t(
        "Ищите по своей локальной библиотеке",
        "Search your local library"
    )
    val nothingFound: String get() = t("Ничего не найдено", "Nothing found")

    val newPlaylist: String get() = t("Новый плейлист", "New playlist")
    val playlistName: String get() = t("Название плейлиста", "Playlist name")
    val deletePlaylistTitle: String get() = t("Удалить плейлист?", "Delete playlist?")
    val favorites: String get() = t("Избранное", "Favorites")
    val edit: String get() = t("Изменить порядок", "Reorder")
    val addSongs: String get() = t("Добавить песни", "Add songs")
    val emptyPlaylist: String get() = t("В плейлисте пока нет песен", "This playlist is empty")
    val noPlaylists: String get() = t("Создайте свой первый плейлист", "Create your first playlist")
    val moveUp: String get() = t("Выше", "Move up")
    val moveDown: String get() = t("Ниже", "Move down")
    val choosePlaylist: String get() = t("Выберите плейлист", "Choose a playlist")
    val allSongsAdded: String get() = t("Все песни уже в плейлисте", "All songs are already added")

    val profileTitle: String get() = t("Профиль", "Profile")
    val defaultUserName: String get() = t("Слушатель", "Listener")
    val editName: String get() = t("Ваше имя", "Your name")
    val changePhoto: String get() = t("Сменить фото", "Change photo")
    val songsStat: String get() = t("Песен", "Songs")
    val playlistsStat: String get() = t("Плейлистов", "Playlists")
    val playsStat: String get() = t("Прослушиваний", "Plays")
    val listenTimeStat: String get() = t("Время", "Listened")
    val topTracks: String get() = t("Чаще всего слушаете", "Most played")
    val noStatsYet: String get() = t("Статистика появится после первых прослушиваний", "Stats will appear after you listen to something")
    fun listenTime(ms: Long): String {
        val m = ms / 60000
        val h = m / 60
        return if (h > 0) t("$h ч ${m % 60} мин", "${h}h ${m % 60}m") else t("$m мин", "${m}m")
    }

    val appearance: String get() = t("Внешний вид", "Appearance")
    val language: String get() = t("Язык", "Language")
    val russian: String get() = "Русский"
    val english: String get() = "English"
    val liquidGlass: String get() = "Liquid Glass"
    val liquidGlassDesc: String get() = t("Стеклянные панели с размытием", "Frosted glass panels with blur")
    val glassIntensity: String get() = t("Интенсивность стекла", "Glass intensity")
    val accentColor: String get() = t("Акцентный цвет", "Accent color")
    val dynamicBg: String get() = t("Фон из обложки", "Artwork background")
    val dynamicBgDesc: String get() = t("Цвета плеера зависят от обложки", "Player colors follow the cover")
    val about: String get() = t("О приложении", "About")
    val versionLabel: String get() = t("Версия 2.0", "Version 2.0")
    val accentNames: List<String>
        get() = listOf(t("Фиолетовый", "Violet"), t("Орхидея", "Orchid"), t("Индиго", "Indigo"), t("Роза", "Rose"))

    val queue: String get() = t("Очередь", "Queue")
    val queueEmpty: String get() = t("Очередь пуста", "Queue is empty")
    val sleepTimer: String get() = t("Таймер сна", "Sleep timer")
    val sleepOff: String get() = t("Выключить таймер", "Turn off timer")
    fun sleepActive(min: Int): String = t("Остановится через $min мин", "Stops in $min min")
    val title: String get() = t("Название", "Title")
    val artist: String get() = t("Исполнитель", "Artist")
    val album: String get() = t("Альбом", "Album")
    val duration: String get() = t("Длительность", "Duration")
    val volume: String get() = t("Громкость", "Volume")
    val ok: String get() = "OK"
}

val LocalStrings = staticCompositionLocalOf { Strings(true) }
