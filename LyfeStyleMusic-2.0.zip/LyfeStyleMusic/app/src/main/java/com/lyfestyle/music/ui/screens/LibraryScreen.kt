package com.lyfestyle.music.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyfestyle.music.R
import com.lyfestyle.music.ui.AppViewModel
import com.lyfestyle.music.ui.LocalStrings
import com.lyfestyle.music.ui.components.AvatarImage
import com.lyfestyle.music.ui.components.TrackRow
import com.lyfestyle.music.ui.components.bounceClick
import com.lyfestyle.music.ui.components.liquidGlass
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import com.lyfestyle.music.ui.theme.LyfeColors

@Composable
fun LibraryScreen(
    vm: AppViewModel,
    listState: LazyListState,
    bottomPad: Dp,
    onOpenProfile: () -> Unit,
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val settings = LocalSettings.current
    val tracks by vm.tracks.collectAsState()
    val loading by vm.loading.collectAsState()
    val ps by vm.player.state.collectAsState()
    val favs by vm.store.favorites.collectAsState()

    val rot = remember { Animatable(0f) }
    LaunchedEffect(loading) {
        if (loading) {
            while (true) rot.animateTo(rot.value + 360f, tween(800, easing = LinearEasing))
        } else {
            rot.snapTo(0f)
        }
    }

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
        // Шапка
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(34.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White)) { append("LyfeStyle ") }
                    withStyle(SpanStyle(color = accent.main.copy(alpha = 1f))) { append("Music") }
                },
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Italic,
                modifier = Modifier.weight(1f),
                maxLines = 1,
            )
            Box(
                Modifier.size(50.dp).liquidGlass(25.dp, glow = true).bounceClick(onOpenProfile, 0.9f),
                contentAlignment = Alignment.Center,
            ) { AvatarImage(settings.avatarVersion, 44.dp) }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 12.dp, top = 14.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(s.songsCount(tracks.size), color = LyfeColors.TextSecondary, fontSize = 17.sp, modifier = Modifier.weight(1f))
            Box(
                Modifier.size(44.dp).bounceClick({ if (tracks.isNotEmpty()) vm.player.shuffleAll(tracks) }, 0.88f),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Shuffle, s.shuffle, tint = accent.main, modifier = Modifier.size(26.dp)) }
            Box(Modifier.size(44.dp).bounceClick({ vm.refresh() }, 0.88f), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Refresh, s.refresh, tint = accent.main, modifier = Modifier.size(28.dp).rotate(rot.value))
            }
        }

        if (tracks.isEmpty() && !loading) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(s.noMusic, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(s.noMusicHint, color = LyfeColors.TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = bottomPad),
            ) {
                itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
                    TrackRow(
                        track = t,
                        current = ps.currentId == t.id,
                        favorite = t.id in favs,
                        onClick = { vm.player.play(tracks, i) },
                    )
                }
            }
        }
    }
}
