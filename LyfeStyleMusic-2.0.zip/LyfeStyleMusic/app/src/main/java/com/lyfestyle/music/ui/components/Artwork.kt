package com.lyfestyle.music.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AColor
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lyfestyle.music.data.CoverStore
import com.lyfestyle.music.data.Track
import androidx.compose.runtime.mutableIntStateOf
import com.lyfestyle.music.ui.theme.LyfeColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Collections

/** Загрузка обложек: MediaStore thumbnail (Android 10+) или встроенная картинка, с LRU-кэшем. */
object ArtworkLoader {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtMost(64 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing: MutableSet<String> = Collections.synchronizedSet(HashSet())
    private val gate = Semaphore(4)

    /** Растёт при смене/сбросе пользовательской обложки — заставляет UI перезагрузить картинки. */
    val revision = mutableIntStateOf(0)

    fun invalidate(id: Long) {
        for (b in intArrayOf(160, 320, 640, 1024)) {
            cache.remove(key(id, b))
            missing.remove(key(id, b))
        }
        revision.intValue = revision.intValue + 1
    }

    fun bucket(px: Int): Int = when {
        px <= 160 -> 160
        px <= 320 -> 320
        px <= 640 -> 640
        else -> 1024
    }

    private fun key(id: Long, px: Int) = "$id@$px"

    fun peek(track: Track?, px: Int): Bitmap? = track?.let { cache.get(key(it.id, px)) }

    suspend fun load(ctx: Context, track: Track, px: Int): Bitmap? {
        val k = key(track.id, px)
        cache.get(k)?.let { return it }
        if (missing.contains(k)) return null
        val bmp = gate.withPermit { withContext(Dispatchers.IO) { decode(ctx, track, px) } }
        if (bmp != null) cache.put(k, bmp) else missing.add(k)
        return bmp
    }

    private fun decode(ctx: Context, t: Track, px: Int): Bitmap? {
        val custom = CoverStore.file(ctx, t.id)
        if (custom.exists()) {
            val c = decodeFile(custom.path, px)
            if (c != null) return c
        }
        var bmp: Bitmap? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            bmp = try {
                ctx.contentResolver.loadThumbnail(t.uri, Size(px, px), null)
            } catch (_: Throwable) {
                null
            }
        }
        if (bmp == null) bmp = embedded(ctx, t, px)
        if (bmp != null && bmp.config == Bitmap.Config.HARDWARE) {
            bmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
        }
        return bmp
    }

    private fun decodeFile(path: String, px: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (_: Throwable) {
        null
    }

    private fun embedded(ctx: Context, t: Track, px: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, t.uri)
            val bytes = r.embeddedPicture ?: return null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
        } catch (_: Throwable) {
            null
        } finally {
            try {
                r.release()
            } catch (_: Throwable) {
            }
        }
    }
}

@Composable
fun rememberArtwork(track: Track?, size: Dp): State<ImageBitmap?> {
    val ctx = LocalContext.current.applicationContext
    val px = ArtworkLoader.bucket(with(LocalDensity.current) { size.roundToPx() })
    return produceState<ImageBitmap?>(
        initialValue = ArtworkLoader.peek(track, px)?.asImageBitmap(),
        track?.id,
        px,
        ArtworkLoader.revision.intValue,
    ) {
        value = if (track == null) null else ArtworkLoader.load(ctx, track, px)?.asImageBitmap()
    }
}

/** Квадратная обложка со стильной заглушкой, если картинки нет. */
@Composable
fun Artwork(
    track: Track?,
    modifier: Modifier = Modifier,
    radius: Dp = 16.dp,
    decodeSize: Dp = 160.dp,
    fade: Boolean = false,
    border: Boolean = true,
) {
    val bmp by rememberArtwork(track, decodeSize)
    val shape = RoundedCornerShape(radius)
    var m = modifier.clip(shape).background(
        Brush.linearGradient(listOf(Color(0xFF2A1F45), Color(0xFF120D1F)))
    )
    if (border) m = m.border(1.dp, Color.White.copy(alpha = 0.08f), shape)
    Box(m, contentAlignment = Alignment.Center) {
        val b = bmp
        if (b == null) {
            Icon(
                Icons.Rounded.MusicNote, null,
                tint = Color(0xFFB9A7E8).copy(alpha = 0.75f),
                modifier = Modifier.fillMaxSize(0.42f),
            )
        } else if (fade) {
            Crossfade(targetState = b, label = "artFade") {
                Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        } else {
            Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}

/** Две цвета для динамического фона плеера, полученные из обложки и смешанные с акцентом. */
fun computePalette(src: Bitmap?, accent: Color): Pair<Color, Color> {
    if (src == null) return accent to accent
    return try {
        val n = 24
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)
        val hsv = FloatArray(3)
        var r = 0.0
        var g = 0.0
        var b = 0.0
        var ws = 0.0
        for (p in px) {
            AColor.colorToHSV(p, hsv)
            val w = hsv[1] * hsv[2] + 0.02
            r += AColor.red(p) * w
            g += AColor.green(p) * w
            b += AColor.blue(p) * w
            ws += w
        }
        val avg = AColor.rgb((r / ws).toInt(), (g / ws).toInt(), (b / ws).toInt())
        AColor.colorToHSV(avg, hsv)
        val sat = hsv[1]
        val art = Color(avg)
        val t = (sat * 2.8f).coerceIn(0f, 1f)
        val mixed = lerp(accent, art, t)
        val m = FloatArray(3)
        AColor.colorToHSV(mixed.toArgbInt(), m)
        val c1 = Color(AColor.HSVToColor(floatArrayOf(m[0], m[1].coerceAtLeast(0.68f), m[2].coerceIn(0.55f, 0.95f))))
        val c2 = Color(AColor.HSVToColor(floatArrayOf((m[0] + 38f) % 360f, m[1].coerceAtLeast(0.6f), (m[2] * 0.78f).coerceIn(0.38f, 0.75f))))
        c1 to c2
    } catch (_: Throwable) {
        accent to accent
    }
}

private fun Color.toArgbInt(): Int = AColor.argb(
    (alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt()
)
