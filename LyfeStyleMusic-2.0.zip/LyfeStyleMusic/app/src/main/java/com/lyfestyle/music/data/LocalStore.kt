package com.lyfestyle.music.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Локальное хранилище: плейлисты, избранное, статистика и настройки (SharedPreferences + JSON). */
class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("lyfe_store", Context.MODE_PRIVATE)

    private val _playlists = MutableStateFlow(loadPlaylists())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private val _favorites = MutableStateFlow(loadFavorites())
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    private val _playCounts = MutableStateFlow(loadCounts())
    val playCounts: StateFlow<Map<Long, Int>> = _playCounts.asStateFlow()

    private val _listenMs = MutableStateFlow(prefs.getLong("listen_ms", 0L))
    val listenMs: StateFlow<Long> = _listenMs.asStateFlow()

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    // ---------- Плейлисты ----------

    fun createPlaylist(name: String, initial: List<Long> = emptyList()): String {
        val id = UUID.randomUUID().toString()
        val p = Playlist(id, name.trim().ifBlank { "Playlist" }, initial.distinct(), System.currentTimeMillis())
        updatePlaylists { it + p }
        return id
    }

    fun renamePlaylist(id: String, name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        updatePlaylists { l -> l.map { if (it.id == id) it.copy(name = n) else it } }
    }

    fun deletePlaylist(id: String) = updatePlaylists { l -> l.filterNot { it.id == id } }

    fun addTracks(id: String, ids: List<Long>) = updatePlaylists { l ->
        l.map { p ->
            if (p.id == id) p.copy(trackIds = (p.trackIds + ids).distinct()) else p
        }
    }

    fun removeTrack(id: String, trackId: Long) = updatePlaylists { l ->
        l.map { p -> if (p.id == id) p.copy(trackIds = p.trackIds.filterNot { it == trackId }) else p }
    }

    fun moveTrack(id: String, from: Int, to: Int) = updatePlaylists { l ->
        l.map { p ->
            if (p.id != id || from !in p.trackIds.indices || to !in p.trackIds.indices) p
            else {
                val m = p.trackIds.toMutableList()
                val item = m.removeAt(from)
                m.add(to, item)
                p.copy(trackIds = m)
            }
        }
    }

    private fun updatePlaylists(block: (List<Playlist>) -> List<Playlist>) {
        val new = block(_playlists.value)
        _playlists.value = new
        val arr = JSONArray()
        new.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("created", p.createdAt)
                    .put("tracks", JSONArray(p.trackIds))
            )
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    private fun loadPlaylists(): List<Playlist> {
        val raw = prefs.getString("playlists", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val t = o.optJSONArray("tracks") ?: JSONArray()
                Playlist(
                    id = o.getString("id"),
                    name = o.optString("name", "Playlist"),
                    trackIds = List(t.length()) { j -> t.getLong(j) },
                    createdAt = o.optLong("created", 0L),
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    // ---------- Избранное ----------

    fun toggleFavorite(trackId: Long) {
        val set = _favorites.value.toMutableSet()
        if (!set.add(trackId)) set.remove(trackId)
        _favorites.value = set
        prefs.edit().putString("favorites", JSONArray(set.toList()).toString()).apply()
    }

    private fun loadFavorites(): Set<Long> {
        val raw = prefs.getString("favorites", null) ?: return emptySet()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getLong(it) }.toSet()
        } catch (_: Exception) {
            emptySet()
        }
    }

    // ---------- Статистика ----------

    fun recordPlay(trackId: Long) {
        val m = _playCounts.value.toMutableMap()
        m[trackId] = (m[trackId] ?: 0) + 1
        _playCounts.value = m
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), v) }
        prefs.edit().putString("play_counts", o.toString()).apply()
    }

    fun addListenMs(delta: Long) {
        if (delta <= 0) return
        val v = _listenMs.value + delta
        _listenMs.value = v
        prefs.edit().putLong("listen_ms", v).apply()
    }

    private fun loadCounts(): Map<Long, Int> {
        val raw = prefs.getString("play_counts", null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            val out = HashMap<Long, Int>()
            o.keys().forEach { k -> k.toLongOrNull()?.let { out[it] = o.getInt(k) } }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }

    // ---------- Настройки ----------

    fun updateSettings(block: (AppSettings) -> AppSettings) {
        val s = block(_settings.value)
        _settings.value = s
        prefs.edit()
            .putString("language", s.language)
            .putBoolean("liquid_glass", s.liquidGlass)
            .putFloat("glass_intensity", s.glassIntensity)
            .putInt("accent", s.accentIndex)
            .putBoolean("dynamic_bg", s.dynamicBackground)
            .putString("user_name", s.userName)
            .putLong("avatar_version", s.avatarVersion)
            .apply()
    }

    private fun loadSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            language = prefs.getString("language", d.language) ?: d.language,
            liquidGlass = prefs.getBoolean("liquid_glass", d.liquidGlass),
            glassIntensity = prefs.getFloat("glass_intensity", d.glassIntensity),
            accentIndex = prefs.getInt("accent", d.accentIndex),
            dynamicBackground = prefs.getBoolean("dynamic_bg", d.dynamicBackground),
            userName = prefs.getString("user_name", "") ?: "",
            avatarVersion = prefs.getLong("avatar_version", 0L),
        )
    }
}
