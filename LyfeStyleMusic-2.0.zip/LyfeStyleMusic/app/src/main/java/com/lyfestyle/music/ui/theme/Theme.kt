package com.lyfestyle.music.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.lyfestyle.music.data.AppSettings

object LyfeColors {
    val Bg = Color(0xFF07050D)
    val BgDeep = Color(0xFF0B0714)
    val SurfaceHigh = Color(0xFF1A1228)
    val Surface = Color(0xFF140E1F)
    val TextSecondary = Color(0xFFA79FBF)
    val TextMuted = Color(0xFF7A7291)
    val Lavender = Color(0xFFC9B3FF)
    val Purple = Color(0xFF9B5CFF)
}

class AccentPalette(val main: Color, val soft: Color)

val Accents = listOf(
    AccentPalette(Color(0xFF9B5CFF), Color(0xFFC9B3FF)), // Violet
    AccentPalette(Color(0xFFD35CFF), Color(0xFFF1BDFF)), // Orchid
    AccentPalette(Color(0xFF6C7CFF), Color(0xFFBAC3FF)), // Indigo
    AccentPalette(Color(0xFFFF5C9D), Color(0xFFFFB8D4)), // Rose
)

val LocalAccent = staticCompositionLocalOf { Accents[0] }
val LocalSettings = staticCompositionLocalOf { AppSettings() }

@Composable
fun LyfeTheme(accent: AccentPalette, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent.main,
        onPrimary = Color.White,
        secondary = accent.soft,
        onSecondary = Color.Black,
        background = LyfeColors.Bg,
        onBackground = Color.White,
        surface = LyfeColors.Surface,
        onSurface = Color.White,
        surfaceVariant = LyfeColors.SurfaceHigh,
        onSurfaceVariant = LyfeColors.TextSecondary,
        surfaceContainer = LyfeColors.SurfaceHigh,
        surfaceContainerHigh = LyfeColors.SurfaceHigh,
        outline = LyfeColors.TextMuted,
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
