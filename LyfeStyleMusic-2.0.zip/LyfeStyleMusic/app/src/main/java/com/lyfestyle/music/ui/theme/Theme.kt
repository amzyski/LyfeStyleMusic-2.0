package com.lyfestyle.music.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.lyfestyle.music.data.AppSettings

object LyfeColors {
    val Bg = Color(0xFF07050D)
    val BgDeep = Color(0xFF0B0714)
    val SurfaceHigh = Color(0xFF1A1228)
    val Surface = Color(0xFF140E1F)
    val TextSecondary = Color(0xFFAFA2D6)
    val TextMuted = Color(0xFF7A7291)
    val Lavender = Color(0xFFC3A3FF)
    val Purple = Color(0xFF9146FF)
}

class AccentPalette(val main: Color, val soft: Color)

val Accents = listOf(
    AccentPalette(Color(0xFF9146FF), Color(0xFFC3A3FF)), // Violet
    AccentPalette(Color(0xFFD13DFF), Color(0xFFF0B3FF)), // Orchid
    AccentPalette(Color(0xFF5A6CFF), Color(0xFFAEB9FF)), // Indigo
    AccentPalette(Color(0xFFFF3F90), Color(0xFFFFA8CC)), // Rose
    AccentPalette(Color(0xFFFF3A4E), Color(0xFFFFA9B1)), // Red
    AccentPalette(Color(0xFFFFB81F), Color(0xFFFFDE85)), // Yellow
    AccentPalette(Color(0xFF1FD36C), Color(0xFFA6EFC6)), // Green
)

val LocalAccent = staticCompositionLocalOf { Accents[0] }
val LocalSettings = staticCompositionLocalOf { AppSettings() }

@Composable
fun LyfeTheme(accent: AccentPalette, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent.main,
        onPrimary = Color.White,
        secondary = accent.soft,
        onSecondary = Color.Black,
        background = LyfeColors.Bg,
        onBackground = Color.White,
        surface = LyfeColors.Surface,
        onSurface = Color.White,
        surfaceVariant = LyfeColors.SurfaceHigh,
        onSurfaceVariant = LyfeColors.TextSecondary,
        surfaceContainer = LyfeColors.SurfaceHigh,
        surfaceContainerHigh = LyfeColors.SurfaceHigh,
        outline = LyfeColors.TextMuted,
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
