package com.lyfestyle.music.ui.components

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import com.lyfestyle.music.ui.theme.LyfeColors
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Liquid Glass.
 *
 * Содержимое «позади» стекла записывается в GraphicsLayer ([glassSource]); каждая стеклянная
 * панель рисует из него свой фрагмент с размытием (RenderEffect, Android 12+),
 * затем поверх — тонировка, внутренние блики, цветная рефракционная кайма и свечение.
 * На Android 8–11 размытия нет: панель получает более плотную тонировку.
 */
@Stable
class GlassState(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassState(): GlassState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassState(layer) }
}

val LocalGlass = compositionLocalOf<GlassState?> { null }

/** Помечает контейнер как источник фона для стеклянных элементов (они должны быть его «соседями», а не детьми). */
fun Modifier.glassSource(state: GlassState): Modifier = this
    .onGloballyPositioned { state.origin = it.positionInRoot() }
    .drawWithContent {
        val sz = IntSize(size.width.roundToInt(), size.height.roundToInt())
        if (sz.width > 0 && sz.height > 0) {
            state.layer.record(density = this, layoutDirection = layoutDirection, size = sz) {
                this@drawWithContent.drawContent()
            }
            drawLayer(state.layer)
        } else {
            drawContent()
        }
    }

@Composable
fun Modifier.liquidGlass(
    cornerRadius: Dp,
    strength: Float = 1f,
    backdrop: Boolean = true,
    glow: Boolean = true,
    tint: Color = Color.Unspecified,
): Modifier {
    val settings = LocalSettings.current
    val accent = LocalAccent.current
    val state = LocalGlass.current
    val layer = rememberGraphicsLayer()
    var pos by remember { mutableStateOf(Offset.Zero) }
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
        state != null && backdrop && settings.liquidGlass
    val blurPx = with(LocalDensity.current) { (10f + 26f * settings.glassIntensity).dp.toPx() }
    val effect = remember(blurPx) { BlurEffect(blurPx, blurPx, TileMode.Clamp) }
    val tintColor = if (tint == Color.Unspecified) accent.main else tint
    val soft = accent.soft
    val liquid = settings.liquidGlass
    val k = strength * (0.7f + 0.6f * settings.glassIntensity)

    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .drawBehind {
            val w = size.width
            val h = size.height
            if (w <= 1f || h <= 1f) return@drawBehind
            val r = min(cornerRadius.toPx(), min(w, h) / 2f)
            val corner = CornerRadius(r)
            val dp = 1.dp.toPx()

            if (!liquid) {
                // Плоский режим (Liquid Glass выключен)
                drawRoundRect(color = Color(0xFF17101F).copy(alpha = 0.92f), cornerRadius = corner)
                drawRoundRect(color = Color.White.copy(alpha = 0.10f), cornerRadius = corner, style = Stroke(dp))
                return@drawBehind
            }

            val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }

            // 1. Внешняя глубина: тёмная тень + фиолетовое свечение
            if (glow) {
                for (i in 1..6) {
                    val e = i * 2.2f * dp
                    drawRoundRect(
                        color = Color.Black.copy(alpha = 0.18f * (1f - i / 7f)),
                        topLeft = Offset(-e, -e + 3f * dp),
                        size = Size(w + 2 * e, h + 2 * e),
                        cornerRadius = CornerRadius(r + e),
                        style = Stroke(2.2f * dp),
                    )
                }
                for (i in 1..6) {
                    val e = i * 2.6f * dp
                    drawRoundRect(
                        color = tintColor.copy(alpha = 0.11f * k * (1f - i / 7f)),
                        topLeft = Offset(-e, -e),
                        size = Size(w + 2 * e, h + 2 * e),
                        cornerRadius = CornerRadius(r + e),
                        style = Stroke(2.6f * dp),
                    )
                }
            }

            // 2. Тело: размытый фон позади + тёмная тонировка
            if (canBlur && state != null) {
                val ox = pos.x - state.origin.x
                val oy = pos.y - state.origin.y
                val pad = (blurPx * 2f).roundToInt()
                val sz = IntSize(w.roundToInt() + 2 * pad, h.roundToInt() + 2 * pad)
                layer.record(density = this, layoutDirection = layoutDirection, size = sz) {
                    translate(pad - ox, pad - oy) { drawLayer(state.layer) }
                }
                if (layer.renderEffect !== effect) layer.renderEffect = effect
                clipPath(path) {
                    translate(-pad.toFloat(), -pad.toFloat()) { drawLayer(layer) }
                }
                drawPath(path, Color(0xFF0A0614).copy(alpha = 0.50f))
            } else {
                drawPath(path, Color(0xFF0D0818).copy(alpha = 0.86f))
            }

            clipPath(path) {
                // 3. Объём: светлее сверху, глубокий фиолетовый снизу
                drawRect(
                    Brush.verticalGradient(
                        listOf(
                            tintColor.copy(alpha = 0.10f * k),
                            Color.Transparent,
                            tintColor.copy(alpha = 0.22f * k),
                        )
                    )
                )
                // свечение слева
                drawRect(
                    Brush.horizontalGradient(
                        listOf(soft.copy(alpha = 0.26f * k), Color.Transparent),
                        startX = 0f, endX = w * 0.38f,
                    )
                )
                // нижняя дымка
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, tintColor.copy(alpha = 0.30f * k)),
                        startY = h * 0.45f, endY = h,
                    )
                )
                // блики-«полосы» внутри стекла
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.07f * k), Color.Transparent),
                        startX = w * 0.52f, endX = w * 0.74f,
                    )
                )
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, soft.copy(alpha = 0.08f * k), Color.Transparent),
                        startX = w * 0.80f, endX = w * 0.95f,
                    )
                )

                // 4. Внутренняя тень по краю — глубина
                val ins = min(2.4f * dp, min(w, h) * 0.05f)
                for (j in 1..5) {
                    drawRoundRect(
                        color = Color.Black.copy(alpha = 0.085f),
                        cornerRadius = corner,
                        style = Stroke(width = j * ins * 2f),
                    )
                }

                // 5. Мягкий верхний блик + острая кромка + фиолетовая линия снизу
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.10f * k), Color.Transparent),
                        startY = 0f, endY = h * 0.45f,
                    ),
                    topLeft = Offset(w * 0.05f, 1.2f * dp),
                    size = Size(w * 0.9f, h * 0.42f),
                    cornerRadius = CornerRadius(r),
                )
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.50f * k), Color.Transparent),
                        startX = w * 0.12f, endX = w * 0.88f,
                    ),
                    topLeft = Offset(w * 0.12f, 2.2f * dp),
                    size = Size(w * 0.76f, 1.4f * dp),
                    cornerRadius = CornerRadius(dp),
                )
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, soft.copy(alpha = 0.60f * k), Color.Transparent),
                        startX = w * 0.10f, endX = w * 0.90f,
                    ),
                    topLeft = Offset(w * 0.10f, h - 3.6f * dp),
                    size = Size(w * 0.80f, 1.5f * dp),
                    cornerRadius = CornerRadius(dp),
                )
            }

            // 6. Внутренняя кромка («толщина» стекла)
            val bi = 3.6f * dp
            if (w > bi * 4 && h > bi * 4) {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.26f * k), Color.Transparent, soft.copy(alpha = 0.28f * k)),
                        start = Offset(0f, 0f), end = Offset(w, h),
                    ),
                    topLeft = Offset(bi, bi),
                    size = Size(w - 2 * bi, h - 2 * bi),
                    cornerRadius = CornerRadius((r - bi).coerceAtLeast(0f)),
                    style = Stroke(1.1f * dp),
                )
            }

            // 7. Внешняя кромка: светлая сверху, фиолетовая снизу
            val rim = 1.3f * dp
            val kk = k.coerceAtMost(1.2f)
            drawRoundRect(
                brush = Brush.verticalGradient(
                    0f to Color.White.copy(alpha = 0.72f * kk),
                    0.30f to Color(0xFFD9CCFF).copy(alpha = 0.22f),
                    0.68f to tintColor.copy(alpha = 0.30f),
                    1f to soft.copy(alpha = 0.90f * kk),
                ),
                cornerRadius = corner,
                style = Stroke(rim),
            )
            drawRoundRect(
                brush = Brush.linearGradient(
                    listOf(Color.White.copy(alpha = 0.60f * kk), Color.Transparent),
                    start = Offset(0f, 0f), end = Offset(w * 0.22f, h),
                ),
                cornerRadius = corner,
                style = Stroke(rim),
            )
            drawRoundRect(
                brush = Brush.linearGradient(
                    listOf(soft.copy(alpha = 0.55f * kk), Color.Transparent),
                    start = Offset(w, h), end = Offset(w * 0.8f, 0f),
                ),
                cornerRadius = corner,
                style = Stroke(rim),
            )

            // 8. Едва заметная рефракционная кайма
            val fi = 2.2f * dp
            if (w > fi * 4 && h > fi * 4) {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(
                            Color(0xFF5CE1FF).copy(alpha = 0.12f * k),
                            Color.Transparent,
                            Color(0xFFFF5CE1).copy(alpha = 0.12f * k),
                        ),
                        start = Offset(w, 0f), end = Offset(0f, h),
                    ),
                    topLeft = Offset(fi, fi),
                    size = Size(w - 2 * fi, h - 2 * fi),
                    cornerRadius = CornerRadius((r - fi).coerceAtLeast(0f)),
                    style = Stroke(dp),
                )
            }
        }
}

/** «Линза» под активной вкладкой навигации: тёмная, с фиолетовым свечением по нижнему краю. */
@Composable
fun Modifier.glassLens(cornerRadius: Dp): Modifier {
    val accent = LocalAccent.current
    val liquid = LocalSettings.current.liquidGlass
    return this.drawBehind {
        val w = size.width
        val h = size.height
        if (w <= 1f || h <= 1f) return@drawBehind
        val r = min(cornerRadius.toPx(), min(w, h) / 2f)
        val corner = CornerRadius(r)
        val dp = 1.dp.toPx()
        val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }
        if (!liquid) {
            drawPath(path, accent.main.copy(alpha = 0.18f))
            return@drawBehind
        }
        drawPath(
            path,
            Brush.verticalGradient(listOf(Color(0xFF1B1030).copy(alpha = 0.55f), Color(0xFF2B1655).copy(alpha = 0.60f)))
        )
        clipPath(path) {
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.Transparent, accent.main.copy(alpha = 0.48f)),
                    startY = h * 0.5f, endY = h,
                )
            )
            drawRect(
                Brush.horizontalGradient(
                    listOf(accent.soft.copy(alpha = 0.12f), Color.Transparent, accent.soft.copy(alpha = 0.07f))
                )
            )
            val ins = min(3f * dp, min(w, h) * 0.06f)
            for (j in 1..4) {
                drawRoundRect(Color.Black.copy(alpha = 0.10f), cornerRadius = corner, style = Stroke(j * ins * 2f))
            }
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, accent.soft.copy(alpha = 0.95f), Color.Transparent),
                    startX = w * 0.15f, endX = w * 0.85f,
                ),
                topLeft = Offset(w * 0.15f, h - 3f * dp),
                size = Size(w * 0.70f, 1.6f * dp),
                cornerRadius = CornerRadius(dp),
            )
        }
        drawRoundRect(
            brush = Brush.verticalGradient(
                0f to accent.soft.copy(alpha = 0.50f),
                0.5f to accent.soft.copy(alpha = 0.16f),
                1f to accent.main.copy(alpha = 0.95f),
            ),
            cornerRadius = corner,
            style = Stroke(1.3f * dp),
        )
    }
}

/** Пружинящее нажатие без ripple. */
@Composable
fun Modifier.bounceClick(
    onClick: () -> Unit,
    pressedScale: Float = 0.93f,
    enabled: Boolean = true,
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 600f),
        label = "bounce",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Круглая стеклянная кнопка. */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    tint: Color = Color.White,
    glassTint: Color = Color.Unspecified,
) {
    Box(
        modifier = modifier
            .size(size)
            .liquidGlass(size / 2, strength = 0.9f, glow = false, tint = glassTint)
            .bounceClick(onClick, 0.88f),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription, tint = tint, modifier = Modifier.size(iconSize))
    }
}

/**
 * Размытие + затемнение под верхней панелью: контент, который уходит вверх, плавно
 * размывается и темнеет, а к нижней границе панели эффект сходит на нет.
 * Элемент должен быть «соседом» glassSource, а не его потомком.
 */
@Composable
fun Modifier.blurScrim(blurDp: Dp = 16.dp, dim: Float = 0.62f): Modifier {
    val state = LocalGlass.current
    val layer = rememberGraphicsLayer()
    var pos by remember { mutableStateOf(Offset.Zero) }
    val blurPx = with(LocalDensity.current) { blurDp.toPx() }
    val effect = remember(blurPx) { BlurEffect(blurPx, blurPx, TileMode.Clamp) }
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && state != null
    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawBehind {
            val w = size.width
            val h = size.height
            if (w <= 1f || h <= 1f) return@drawBehind
            if (canBlur && state != null) {
                val ox = pos.x - state.origin.x
                val oy = pos.y - state.origin.y
                val pad = (blurPx * 2f).roundToInt()
                val sz = IntSize(w.roundToInt() + 2 * pad, h.roundToInt() + 2 * pad)
                layer.record(density = this, layoutDirection = layoutDirection, size = sz) {
                    translate(pad - ox, pad - oy) { drawLayer(state.layer) }
                }
                if (layer.renderEffect !== effect) layer.renderEffect = effect
                clipRect {
                    translate(-pad.toFloat(), -pad.toFloat()) { drawLayer(layer) }
                }
            }
            // затемнение
            drawRect(
                Brush.verticalGradient(
                    listOf(
                        LyfeColors.Bg.copy(alpha = dim),
                        LyfeColors.Bg.copy(alpha = dim * 0.55f),
                    )
                )
            )
            // плавное растворение к нижней границе
            drawRect(
                Brush.verticalGradient(
                    0f to Color.White,
                    0.5f to Color.White,
                    1f to Color.Transparent,
                ),
                blendMode = BlendMode.DstIn,
            )
        }
}
