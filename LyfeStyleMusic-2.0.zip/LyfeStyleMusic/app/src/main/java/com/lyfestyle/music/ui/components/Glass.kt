package com.lyfestyle.music.ui.components

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import com.lyfestyle.music.ui.theme.LyfeColors
import kotlin.math.max
import kotlin.math.min

/**
 * Liquid Glass.
 *
 * Содержимое «позади» стекла записывается в GraphicsLayer ([glassSource]); каждая стеклянная
 * панель рисует из него свой фрагмент с размытием (RenderEffect, Android 12+), поверх — тёмная
 * тонировка, объёмная дымка, внутренняя тень, двойная кромка и фиолетовое свечение.
 * На Android 8–11 размытия нет — панель просто плотнее.
 */
@Stable
class GlassState(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassState(): GlassState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassState(layer) }
}

val LocalGlass = compositionLocalOf<GlassState?> { null }

/** Помечает контейнер как источник фона для стеклянных элементов (они должны быть его «соседями», а не детьми). */
fun Modifier.glassSource(state: GlassState): Modifier = this
    .onGloballyPositioned { state.origin = it.positionInRoot() }
    .drawWithContent {
        val sz = IntSize(size.width.roundToInt(), size.height.roundToInt())
        if (sz.width > 0 && sz.height > 0) {
            state.layer.record(density = this, layoutDirection = layoutDirection, size = sz) {
                this@drawWithContent.drawContent()
            }
            drawLayer(state.layer)
        } else {
            drawContent()
        }
    }

/** Рисует размытый фрагмент фона позади элемента, обрезанный по path. */
private fun DrawScope.drawBackdrop(
    state: GlassState,
    layer: GraphicsLayer,
    pos: Offset,
    blurPx: Float,
    effect: BlurEffect,
    path: Path,
) {
    val ox = pos.x - state.origin.x
    val oy = pos.y - state.origin.y
    val pad = (blurPx * 2f).roundToInt()
    val sz = IntSize(size.width.roundToInt() + 2 * pad, size.height.roundToInt() + 2 * pad)
    layer.record(density = this, layoutDirection = layoutDirection, size = sz) {
        translate(pad - ox, pad - oy) { drawLayer(state.layer) }
    }
    if (layer.renderEffect !== effect) layer.renderEffect = effect
    clipPath(path) {
        translate(-pad.toFloat(), -pad.toFloat()) { drawLayer(layer) }
    }
}

// ---------------------------------------------------------------------------------------------
//  Стеклянная панель
// ---------------------------------------------------------------------------------------------

@Composable
fun Modifier.liquidGlass(
    cornerRadius: Dp,
    strength: Float = 1f,
    backdrop: Boolean = true,
    glow: Boolean = true,
    tint: Color = Color.Unspecified,
): Modifier {
    val settings = LocalSettings.current
    val accent = LocalAccent.current
    val state = LocalGlass.current
    val layer = rememberGraphicsLayer()
    var pos by remember { mutableStateOf(Offset.Zero) }
    val liquid = settings.liquidGlass
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && state != null && backdrop && liquid
    val blurPx = with(LocalDensity.current) { (10f + 26f * settings.glassIntensity).dp.toPx() }
    val effect = remember(blurPx) { BlurEffect(blurPx, blurPx, TileMode.Clamp) }
    val tintColor = if (tint == Color.Unspecified) accent.main else tint
    val soft = accent.soft
    val k = strength * (0.7f + 0.6f * settings.glassIntensity)

    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .drawBehind {
            val w = size.width
            val h = size.height
            if (w <= 1f || h <= 1f) return@drawBehind
            val r = min(cornerRadius.toPx(), min(w, h) / 2f)
            val corner = CornerRadius(r)

            if (!liquid) {
                // Плоский режим (Liquid Glass выключен)
                drawRoundRect(Color(0xFF17101F).copy(alpha = 0.92f), cornerRadius = corner)
                drawRoundRect(Color.White.copy(alpha = 0.10f), cornerRadius = corner, style = Stroke(1.dp.toPx()))
                return@drawBehind
            }

            val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }
            if (glow) glassOuter(r, tintColor, k)
            if (canBlur && state != null) drawBackdrop(state, layer, pos, blurPx, effect, path)
            glassBody(path, r, canBlur, tintColor, soft, k)
        }
}

private fun DrawScope.glassOuter(r: Float, tintColor: Color, k: Float) {
    val w = size.width
    val h = size.height
    val dp = 1.dp.toPx()
    // тёмная тень (глубина)
    for (i in 1..6) {
        val e = i * 2.2f * dp
        drawRoundRect(
            color = Color.Black.copy(alpha = 0.18f * (1f - i / 7f)),
            topLeft = Offset(-e, -e + 3f * dp),
            size = Size(w + 2 * e, h + 2 * e),
            cornerRadius = CornerRadius(r + e),
            style = Stroke(2.2f * dp),
        )
    }
    // фиолетовое свечение
    for (i in 1..6) {
        val e = i * 2.6f * dp
        drawRoundRect(
            color = tintColor.copy(alpha = 0.11f * k * (1f - i / 7f)),
            topLeft = Offset(-e, -e),
            size = Size(w + 2 * e, h + 2 * e),
            cornerRadius = CornerRadius(r + e),
            style = Stroke(2.6f * dp),
        )
    }
}

private fun DrawScope.glassBody(path: Path, r: Float, canBlur: Boolean, tintColor: Color, soft: Color, k: Float) {
    val w = size.width
    val h = size.height
    val dp = 1.dp.toPx()
    val corner = CornerRadius(r)

    // Тёмное тело
    drawPath(path, Color(0xFF0A0614).copy(alpha = if (canBlur) 0.50f else 0.86f))

    clipPath(path) {
        // Объём: светлее сверху, глубокий фиолетовый снизу
        drawRect(
            Brush.verticalGradient(
                listOf(
                    tintColor.copy(alpha = 0.10f * k),
                    Color.Transparent,
                    tintColor.copy(alpha = 0.22f * k),
                )
            )
        )
        // Свечение слева
        drawRect(
            Brush.horizontalGradient(
                listOf(soft.copy(alpha = 0.22f * k), Color.Transparent),
                startX = 0f, endX = w * 0.38f,
            )
        )
        // Нижняя дымка
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, tintColor.copy(alpha = 0.28f * k)),
                startY = h * 0.45f, endY = h,
            )
        )
        // Внутренняя тень по краю — глубина
        val ins = min(2.4f * dp, min(w, h) * 0.05f)
        for (j in 1..5) {
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.085f),
                cornerRadius = corner,
                style = Stroke(width = j * ins * 2f),
            )
        }
        // Едва заметный мягкий верхний отсвет (без резких белых линий)
        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.05f * k), Color.Transparent),
                startY = 0f, endY = h * 0.45f,
            ),
            topLeft = Offset(w * 0.05f, 1.2f * dp),
            size = Size(w * 0.9f, h * 0.42f),
            cornerRadius = CornerRadius(r),
        )
        // Фиолетовая линия-свечение снизу
        drawRoundRect(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, soft.copy(alpha = 0.50f * k), Color.Transparent),
                startX = w * 0.10f, endX = w * 0.90f,
            ),
            topLeft = Offset(w * 0.10f, h - 3.6f * dp),
            size = Size(w * 0.80f, 1.5f * dp),
            cornerRadius = CornerRadius(dp),
        )
    }

    // Внутренняя кромка («толщина» стекла)
    val bi = 3.6f * dp
    if (w > bi * 4 && h > bi * 4) {
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.14f * k), Color.Transparent, soft.copy(alpha = 0.22f * k)),
                start = Offset(0f, 0f), end = Offset(w, h),
            ),
            topLeft = Offset(bi, bi),
            size = Size(w - 2 * bi, h - 2 * bi),
            cornerRadius = CornerRadius((r - bi).coerceAtLeast(0f)),
            style = Stroke(1.1f * dp),
        )
    }

    // Внешняя кромка: светлая сверху, фиолетовая снизу
    val rim = 1.3f * dp
    val kk = k.coerceAtMost(1.2f)
    drawRoundRect(
        brush = Brush.verticalGradient(
            0f to Color.White.copy(alpha = 0.50f * kk),
            0.30f to Color(0xFFD9CCFF).copy(alpha = 0.18f),
            0.68f to tintColor.copy(alpha = 0.30f),
            1f to soft.copy(alpha = 0.85f * kk),
        ),
        cornerRadius = corner,
        style = Stroke(rim),
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.40f * kk), Color.Transparent),
            start = Offset(0f, 0f), end = Offset(w * 0.22f, h),
        ),
        cornerRadius = corner,
        style = Stroke(rim),
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(soft.copy(alpha = 0.50f * kk), Color.Transparent),
            start = Offset(w, h), end = Offset(w * 0.8f, 0f),
        ),
        cornerRadius = corner,
        style = Stroke(rim),
    )
}

/** «Линза» под активной вкладкой навигации: тёмная, с фиолетовым свечением по нижнему краю. */
@Composable
fun Modifier.glassLens(cornerRadius: Dp): Modifier {
    val accent = LocalAccent.current
    val liquid = LocalSettings.current.liquidGlass
    return this.drawBehind {
        val w = size.width
        val h = size.height
        if (w <= 1f || h <= 1f) return@drawBehind
        val r = min(cornerRadius.toPx(), min(w, h) / 2f)
        val corner = CornerRadius(r)
        val dp = 1.dp.toPx()
        val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }
        if (!liquid) {
            drawPath(path, accent.main.copy(alpha = 0.18f))
            return@drawBehind
        }
        drawPath(
            path,
            Brush.verticalGradient(listOf(Color(0xFF1B1030).copy(alpha = 0.55f), Color(0xFF2B1655).copy(alpha = 0.60f)))
        )
        clipPath(path) {
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.Transparent, accent.main.copy(alpha = 0.48f)),
                    startY = h * 0.5f, endY = h,
                )
            )
            val ins = min(3f * dp, min(w, h) * 0.06f)
            for (j in 1..4) {
                drawRoundRect(Color.Black.copy(alpha = 0.10f), cornerRadius = corner, style = Stroke(j * ins * 2f))
            }
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, accent.soft.copy(alpha = 0.85f), Color.Transparent),
                    startX = w * 0.15f, endX = w * 0.85f,
                ),
                topLeft = Offset(w * 0.15f, h - 3f * dp),
                size = Size(w * 0.70f, 1.6f * dp),
                cornerRadius = CornerRadius(dp),
            )
        }
        drawRoundRect(
            brush = Brush.verticalGradient(
                0f to accent.soft.copy(alpha = 0.45f),
                0.5f to accent.soft.copy(alpha = 0.14f),
                1f to accent.main.copy(alpha = 0.95f),
            ),
            cornerRadius = corner,
            style = Stroke(1.3f * dp),
        )
    }
}

// ---------------------------------------------------------------------------------------------
//  Стеклянные контейнеры (Compose-слой с размытием)
// ---------------------------------------------------------------------------------------------

/**
 * Размытая копия фона под панелью. Это отдельный слой Compose (graphicsLayer + RenderEffect):
 * в нём рисуется копия содержимого позади панели, а размывает её сам слой.
 */
@Composable
private fun BoxScope.BackdropBlur(state: GlassState, pos: Offset, blurPx: Float, shape: Shape) {
    val effect = remember(blurPx) { BlurEffect(blurPx, blurPx, TileMode.Clamp) }
    Box(
        Modifier
            .matchParentSize()
            .clip(shape)
            .graphicsLayer { renderEffect = effect }
            .drawBehind {
                translate(state.origin.x - pos.x, state.origin.y - pos.y) { drawLayer(state.layer) }
            }
    )
}

/**
 * Стеклянный контейнер (нижняя навигация, мини-плеер): размытый фон, тёмное тело, объём и кромка,
 * затем содержимое.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    cornerRadius: Dp,
    strength: Float = 1f,
    content: @Composable BoxScope.() -> Unit,
) {
    val settings = LocalSettings.current
    val accent = LocalAccent.current
    val state = LocalGlass.current
    val liquid = settings.liquidGlass
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && state != null && liquid
    var pos by remember { mutableStateOf(Offset.Zero) }
    val blurPx = with(LocalDensity.current) { (10f + 26f * settings.glassIntensity).dp.toPx() }
    val k = strength * (0.7f + 0.6f * settings.glassIntensity)
    val main = accent.main
    val soft = accent.soft
    val shape = RoundedCornerShape(cornerRadius)

    Box(
        modifier
            .onGloballyPositioned { pos = it.positionInRoot() }
            .drawBehind {
                if (liquid && size.width > 1f && size.height > 1f) {
                    glassOuter(min(cornerRadius.toPx(), min(size.width, size.height) / 2f), main, k)
                }
            }
    ) {
        if (canBlur && state != null) BackdropBlur(state, pos, blurPx, shape)
        Box(
            Modifier.matchParentSize().drawBehind {
                val w = size.width
                val h = size.height
                if (w <= 1f || h <= 1f) return@drawBehind
                val r = min(cornerRadius.toPx(), min(w, h) / 2f)
                val corner = CornerRadius(r)
                if (!liquid) {
                    drawRoundRect(Color(0xFF17101F).copy(alpha = 0.92f), cornerRadius = corner)
                    drawRoundRect(Color.White.copy(alpha = 0.10f), cornerRadius = corner, style = Stroke(1.dp.toPx()))
                } else {
                    val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }
                    glassBody(path, r, canBlur, main, soft, k)
                }
            }
        )
        content()
    }
}

// ---------------------------------------------------------------------------------------------
//  Размытие и затемнение треков при уходе под панели
// ---------------------------------------------------------------------------------------------

/**
 * Строка списка размывается и темнеет только там, где она заходит под верхнюю панель
 * (край topEdgePx) или под нижние панели (край bottomEdgePx, высота панелей bottomBarPx).
 * Размытие — Android 12+, затемнение — везде.
 */
fun Modifier.edgeBlur(
    state: LazyListState,
    key: Any,
    topEdgePx: Float,
    bottomEdgePx: Float,
    bottomBarPx: Float,
): Modifier = this.graphicsLayer {
    val info = state.layoutInfo
    val item = info.visibleItemsInfo.firstOrNull { it.key == key } ?: return@graphicsLayer
    val s = item.size.toFloat()
    // offset отсчитывается от начала контента без отступа — прибавляем верхний отступ
    val cy = item.offset + s / 2f + info.beforeContentPadding
    var f = 0f
    if (topEdgePx > 0f) {
        f = max(f, ((topEdgePx + 0.2f * s - cy) / (topEdgePx * 0.5f + 0.2f * s)).coerceIn(0f, 1f))
    }
    if (bottomBarPx > 0f && bottomEdgePx > 0f) {
        f = max(f, ((cy - (bottomEdgePx - 0.2f * s)) / (bottomBarPx * 0.5f + 0.2f * s)).coerceIn(0f, 1f))
    }
    if (f > 0.01f) {
        alpha = 1f - 0.55f * f
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val r = f * 12.dp.toPx()
            renderEffect = BlurEffect(r, r, TileMode.Decal)
        }
    }
}

// ---------------------------------------------------------------------------------------------
//  Кнопки
// ---------------------------------------------------------------------------------------------

/** Пружинящее нажатие без ripple. */
@Composable
fun Modifier.bounceClick(
    onClick: () -> Unit,
    pressedScale: Float = 0.93f,
    enabled: Boolean = true,
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 600f),
        label = "bounce",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Круглая стеклянная кнопка. */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    tint: Color = Color.White,
    glassTint: Color = Color.Unspecified,
) {
    Box(
        modifier = modifier
            .size(size)
            .liquidGlass(size / 2, strength = 0.9f, glow = false, tint = glassTint)
            .bounceClick(onClick, 0.88f),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription, tint = tint, modifier = Modifier.size(iconSize))
    }
}
