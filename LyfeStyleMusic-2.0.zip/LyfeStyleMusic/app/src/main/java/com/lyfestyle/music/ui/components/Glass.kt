package com.lyfestyle.music.ui.components

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Liquid Glass.
 *
 * Содержимое «позади» стекла записывается в GraphicsLayer ([glassSource]); каждая стеклянная
 * панель рисует из него свой фрагмент с размытием (RenderEffect, Android 12+),
 * затем поверх — тонировка, внутренние блики, цветная рефракционная кайма и свечение.
 * На Android 8–11 размытия нет: панель получает более плотную тонировку.
 */
@Stable
class GlassState(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassState(): GlassState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassState(layer) }
}

val LocalGlass = compositionLocalOf<GlassState?> { null }

/** Помечает контейнер как источник фона для стеклянных элементов (они должны быть его «соседями», а не детьми). */
fun Modifier.glassSource(state: GlassState): Modifier = this
    .onGloballyPositioned { state.origin = it.positionInRoot() }
    .drawWithContent {
        val sz = IntSize(size.width.roundToInt(), size.height.roundToInt())
        if (sz.width > 0 && sz.height > 0) {
            state.layer.record(density = this, layoutDirection = layoutDirection, size = sz) {
                this@drawWithContent.drawContent()
            }
            drawLayer(state.layer)
        } else {
            drawContent()
        }
    }

@Composable
fun Modifier.liquidGlass(
    cornerRadius: Dp,
    strength: Float = 1f,
    backdrop: Boolean = true,
    glow: Boolean = true,
    tint: Color = Color.Unspecified,
): Modifier {
    val settings = LocalSettings.current
    val accent = LocalAccent.current
    val state = LocalGlass.current
    val layer = rememberGraphicsLayer()
    var pos by remember { mutableStateOf(Offset.Zero) }
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
        state != null && backdrop && settings.liquidGlass
    val blurPx = with(LocalDensity.current) { (6f + 22f * settings.glassIntensity).dp.toPx() }
    val effect = remember(blurPx) { BlurEffect(blurPx, blurPx, TileMode.Clamp) }
    val tintColor = if (tint == Color.Unspecified) accent.main else tint
    val soft = accent.soft
    val liquid = settings.liquidGlass
    val intensity = settings.glassIntensity

    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .drawBehind {
            val w = size.width
            val h = size.height
            if (w <= 1f || h <= 1f) return@drawBehind
            val r = min(cornerRadius.toPx(), min(w, h) / 2f)
            val corner = CornerRadius(r)

            if (!liquid) {
                // Плоский режим (Liquid Glass выключен)
                drawRoundRect(color = Color(0xFF17101F).copy(alpha = 0.92f), cornerRadius = corner)
                drawRoundRect(color = Color.White.copy(alpha = 0.10f), cornerRadius = corner, style = Stroke(1.dp.toPx()))
                return@drawBehind
            }

            val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }
            val s = strength

            // Внешнее мягкое свечение
            if (glow) {
                for (i in 1..5) {
                    val e = i * 3.dp.toPx()
                    drawRoundRect(
                        color = tintColor.copy(alpha = 0.11f * s * (1f - i / 6f)),
                        topLeft = Offset(-e, -e),
                        size = Size(w + 2 * e, h + 2 * e),
                        cornerRadius = CornerRadius(r + e),
                        style = Stroke(width = 3.dp.toPx()),
                    )
                }
            }

            // Размытый фон позади панели
            if (canBlur && state != null) {
                val ox = pos.x - state.origin.x
                val oy = pos.y - state.origin.y
                val pad = (blurPx * 2f).roundToInt()
                val sz = IntSize(w.roundToInt() + 2 * pad, h.roundToInt() + 2 * pad)
                layer.record(density = this, layoutDirection = layoutDirection, size = sz) {
                    translate(pad - ox, pad - oy) { drawLayer(state.layer) }
                }
                if (layer.renderEffect !== effect) layer.renderEffect = effect
                clipPath(path) {
                    translate(-pad.toFloat(), -pad.toFloat()) { drawLayer(layer) }
                }
                drawPath(path, Color(0xFF0B0714).copy(alpha = 0.22f + 0.1f * intensity))
            } else {
                drawPath(path, Color(0xFF120B1E).copy(alpha = 0.80f))
            }

            // Тонировка стекла
            drawPath(
                path,
                Brush.linearGradient(
                    colors = listOf(
                        tintColor.copy(alpha = 0.22f * s),
                        Color.White.copy(alpha = 0.04f),
                        tintColor.copy(alpha = 0.14f * s),
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(w, h),
                )
            )

            clipPath(path) {
                // Нижняя каустика
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(soft.copy(alpha = 0.30f * s), Color.Transparent),
                        center = Offset(w * 0.5f, h * 1.05f),
                        radius = w * 0.55f,
                    )
                )
                // Верхний зеркальный блик
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.White.copy(alpha = 0.30f * s), Color.White.copy(alpha = 0f)),
                        startY = 0f,
                        endY = h * 0.5f,
                    ),
                    topLeft = Offset(w * 0.06f, 1.5.dp.toPx()),
                    size = Size(w * 0.88f, h * 0.46f),
                    cornerRadius = CornerRadius(r * 0.9f),
                )
            }

            // Светлый контур: яркий сверху-слева, лавандовый снизу-справа
            drawRoundRect(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f * s.coerceAtMost(1.2f)),
                        Color.White.copy(alpha = 0.08f),
                        Color.White.copy(alpha = 0.0f),
                        soft.copy(alpha = 0.65f * s.coerceAtMost(1.2f)),
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(w, h),
                ),
                cornerRadius = corner,
                style = Stroke(width = 1.2.dp.toPx()),
            )

            // Цветная рефракционная кайма (циан → маджента) по внутреннему контуру
            val inset = 2.5.dp.toPx()
            if (w > inset * 4 && h > inset * 4) {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF5CE1FF).copy(alpha = 0.38f * s),
                            Color.Transparent,
                            Color(0xFFFF5CE1).copy(alpha = 0.38f * s),
                        ),
                        start = Offset(w, 0f),
                        end = Offset(0f, h),
                    ),
                    topLeft = Offset(inset, inset),
                    size = Size(w - 2 * inset, h - 2 * inset),
                    cornerRadius = CornerRadius((r - inset).coerceAtLeast(0f)),
                    style = Stroke(width = 1.dp.toPx()),
                )
            }
        }
}

/** Пружинящее нажатие без ripple. */
@Composable
fun Modifier.bounceClick(
    onClick: () -> Unit,
    pressedScale: Float = 0.93f,
    enabled: Boolean = true,
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 600f),
        label = "bounce",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Круглая стеклянная кнопка. */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    tint: Color = Color.White,
    glassTint: Color = Color.Unspecified,
) {
    Box(
        modifier = modifier
            .size(size)
            .liquidGlass(size / 2, strength = 0.9f, glow = false, tint = glassTint)
            .bounceClick(onClick, 0.88f),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription, tint = tint, modifier = Modifier.size(iconSize))
    }
}
