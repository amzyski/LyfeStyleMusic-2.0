package com.lyfestyle.music.ui.components

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import com.lyfestyle.music.ui.theme.LyfeColors
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import kotlin.math.max
import kotlin.math.min

/**
 * Liquid Glass.
 *
 * Фон позади панели размывается библиотекой Haze (RenderEffect, Android 12+); поверх рисуются
 * тёмная тонировка, объёмная дымка, внутренняя тень, двойная кромка и фиолетовое свечение.
 * На Android 8–11 размытия нет — панель просто плотнее.
 */
@Stable
class GlassState(val haze: HazeState)

@Composable
fun rememberGlassState(): GlassState = remember { GlassState(HazeState()) }

val LocalGlass = compositionLocalOf<GlassState?> { null }

/** Помечает контейнер как источник фона для стеклянных элементов (они должны быть его «соседями», а не детьми). */
fun Modifier.glassSource(state: GlassState): Modifier = this.hazeSource(state.haze)

// ---------------------------------------------------------------------------------------------
//  Стеклянная панель
// ---------------------------------------------------------------------------------------------

@Composable
fun Modifier.liquidGlass(
    cornerRadius: Dp,
    strength: Float = 1f,
    backdrop: Boolean = true,
    glow: Boolean = true,
    tint: Color = Color.Unspecified,
): Modifier {
    val settings = LocalSettings.current
    val accent = LocalAccent.current
    val state = LocalGlass.current
    val liquid = settings.liquidGlass
    val blurOn = liquid && backdrop && state != null
    val canBlur = blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val tintColor = if (tint == Color.Unspecified) accent.main else tint
    val soft = accent.soft
    val k = strength * (0.7f + 0.6f * settings.glassIntensity)
    val blurDp = (10f + 26f * settings.glassIntensity).dp
    val shape = RoundedCornerShape(cornerRadius)

    if (!liquid) {
        return this
            .clip(shape)
            .drawBehind {
                val r = min(cornerRadius.toPx(), min(size.width, size.height) / 2f)
                drawRoundRect(Color(0xFF17101F).copy(alpha = 0.92f), cornerRadius = CornerRadius(r))
                drawRoundRect(Color.White.copy(alpha = 0.10f), cornerRadius = CornerRadius(r), style = Stroke(1.dp.toPx()))
            }
    }

    var m: Modifier = this
    if (glow) {
        m = m.drawBehind {
            val r = min(cornerRadius.toPx(), min(size.width, size.height) / 2f)
            glassOuter(r, tintColor, k)
        }
    }
    m = m.clip(shape)
    if (blurOn && state != null) {
        m = m.hazeEffect(state.haze) {
            blurRadius = blurDp
            noiseFactor = 0f
        }
    }
    return m.drawBehind {
        val r = min(cornerRadius.toPx(), min(size.width, size.height) / 2f)
        glassBody(r, canBlur, tintColor, soft, k)
    }
}

private fun DrawScope.glassOuter(r: Float, tintColor: Color, k: Float) {
    val w = size.width
    val h = size.height
    if (w <= 1f || h <= 1f) return
    val dp = 1.dp.toPx()
    // тёмная тень (глубина)
    for (i in 1..6) {
        val e = i * 2.2f * dp
        drawRoundRect(
            color = Color.Black.copy(alpha = 0.18f * (1f - i / 7f)),
            topLeft = Offset(-e, -e + 3f * dp),
            size = Size(w + 2 * e, h + 2 * e),
            cornerRadius = CornerRadius(r + e),
            style = Stroke(2.2f * dp),
        )
    }
    // фиолетовое свечение
    for (i in 1..6) {
        val e = i * 2.6f * dp
        drawRoundRect(
            color = tintColor.copy(alpha = 0.11f * k * (1f - i / 7f)),
            topLeft = Offset(-e, -e),
            size = Size(w + 2 * e, h + 2 * e),
            cornerRadius = CornerRadius(r + e),
            style = Stroke(2.6f * dp),
        )
    }
}

private fun DrawScope.glassBody(r: Float, canBlur: Boolean, tintColor: Color, soft: Color, k: Float) {
    val w = size.width
    val h = size.height
    if (w <= 1f || h <= 1f) return
    val dp = 1.dp.toPx()
    val corner = CornerRadius(r)
    val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }

    // Тёмное тело
    drawPath(path, Color(0xFF0A0614).copy(alpha = if (canBlur) 0.46f else 0.86f))

    clipPath(path) {
        // Объём: светлее сверху, глубокий фиолетовый снизу
        drawRect(
            Brush.verticalGradient(
                listOf(
                    tintColor.copy(alpha = 0.10f * k),
                    Color.Transparent,
                    tintColor.copy(alpha = 0.22f * k),
                )
            )
        )
        // Свечение слева
        drawRect(
            Brush.horizontalGradient(
                listOf(soft.copy(alpha = 0.22f * k), Color.Transparent),
                startX = 0f, endX = w * 0.38f,
            )
        )
        // Нижняя дымка
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, tintColor.copy(alpha = 0.28f * k)),
                startY = h * 0.45f, endY = h,
            )
        )
        // Внутренняя тень по краю — глубина
        val ins = min(2.4f * dp, min(w, h) * 0.05f)
        for (j in 1..5) {
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.085f),
                cornerRadius = corner,
                style = Stroke(width = j * ins * 2f),
            )
        }
        // Едва заметный мягкий верхний отсвет (без резких белых линий)
        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.05f * k), Color.Transparent),
                startY = 0f, endY = h * 0.45f,
            ),
            topLeft = Offset(w * 0.05f, 1.2f * dp),
            size = Size(w * 0.9f, h * 0.42f),
            cornerRadius = CornerRadius(r),
        )
        // Фиолетовая линия-свечение снизу
        drawRoundRect(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, soft.copy(alpha = 0.50f * k), Color.Transparent),
                startX = w * 0.10f, endX = w * 0.90f,
            ),
            topLeft = Offset(w * 0.10f, h - 3.6f * dp),
            size = Size(w * 0.80f, 1.5f * dp),
            cornerRadius = CornerRadius(dp),
        )
    }

    // Внутренняя кромка («толщина» стекла)
    val bi = 3.6f * dp
    if (w > bi * 4 && h > bi * 4) {
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.14f * k), Color.Transparent, soft.copy(alpha = 0.22f * k)),
                start = Offset(0f, 0f), end = Offset(w, h),
            ),
            topLeft = Offset(bi, bi),
            size = Size(w - 2 * bi, h - 2 * bi),
            cornerRadius = CornerRadius((r - bi).coerceAtLeast(0f)),
            style = Stroke(1.1f * dp),
        )
    }

    // Внешняя кромка: светлая сверху, фиолетовая снизу
    val rim = 1.3f * dp
    val kk = k.coerceAtMost(1.2f)
    drawRoundRect(
        brush = Brush.verticalGradient(
            0f to Color.White.copy(alpha = 0.50f * kk),
            0.30f to Color(0xFFD9CCFF).copy(alpha = 0.18f),
            0.68f to tintColor.copy(alpha = 0.30f),
            1f to soft.copy(alpha = 0.85f * kk),
        ),
        cornerRadius = corner,
        style = Stroke(rim),
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.40f * kk), Color.Transparent),
            start = Offset(0f, 0f), end = Offset(w * 0.22f, h),
        ),
        cornerRadius = corner,
        style = Stroke(rim),
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(soft.copy(alpha = 0.50f * kk), Color.Transparent),
            start = Offset(w, h), end = Offset(w * 0.8f, 0f),
        ),
        cornerRadius = corner,
        style = Stroke(rim),
    )
}

/** «Линза» под активной вкладкой навигации: тёмная, с фиолетовым свечением по нижнему краю. */
@Composable
fun Modifier.glassLens(cornerRadius: Dp): Modifier {
    val accent = LocalAccent.current
    val liquid = LocalSettings.current.liquidGlass
    return this.drawBehind {
        val w = size.width
        val h = size.height
        if (w <= 1f || h <= 1f) return@drawBehind
        val r = min(cornerRadius.toPx(), min(w, h) / 2f)
        val corner = CornerRadius(r)
        val dp = 1.dp.toPx()
        val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }
        if (!liquid) {
            drawPath(path, accent.main.copy(alpha = 0.18f))
            return@drawBehind
        }
        drawPath(
            path,
            Brush.verticalGradient(listOf(Color(0xFF1B1030).copy(alpha = 0.55f), Color(0xFF2B1655).copy(alpha = 0.60f)))
        )
        clipPath(path) {
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.Transparent, accent.main.copy(alpha = 0.48f)),
                    startY = h * 0.5f, endY = h,
                )
            )
            val ins = min(3f * dp, min(w, h) * 0.06f)
            for (j in 1..4) {
                drawRoundRect(Color.Black.copy(alpha = 0.10f), cornerRadius = corner, style = Stroke(j * ins * 2f))
            }
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, accent.soft.copy(alpha = 0.85f), Color.Transparent),
                    startX = w * 0.15f, endX = w * 0.85f,
                ),
                topLeft = Offset(w * 0.15f, h - 3f * dp),
                size = Size(w * 0.70f, 1.6f * dp),
                cornerRadius = CornerRadius(dp),
            )
        }
        drawRoundRect(
            brush = Brush.verticalGradient(
                0f to accent.soft.copy(alpha = 0.45f),
                0.5f to accent.soft.copy(alpha = 0.14f),
                1f to accent.main.copy(alpha = 0.95f),
            ),
            cornerRadius = corner,
            style = Stroke(1.3f * dp),
        )
    }
}

// ---------------------------------------------------------------------------------------------
//  Верхняя стеклянная панель с «шёлковыми» складками
// ---------------------------------------------------------------------------------------------

private class Fold(val x: Float, val bw: Float, val a: Float, val slope: Float, val light: Boolean)

private val silkFolds = listOf(
    Fold(0.00f, 0.22f, 0.30f, 0.90f, true),
    Fold(0.14f, 0.28f, 0.16f, 1.40f, false),
    Fold(0.36f, 0.20f, 0.15f, 0.70f, true),
    Fold(0.55f, 0.26f, 0.18f, 1.80f, true),
    Fold(0.76f, 0.24f, 0.14f, 1.10f, false),
    Fold(0.28f, 0.52f, 0.09f, -0.60f, true),
    Fold(0.00f, 0.65f, 0.10f, 0.25f, true),
    Fold(0.70f, 0.30f, 0.12f, -1.20f, true),
)

/**
 * Верхняя панель библиотеки: стеклянное полотно во всю ширину под статус-баром,
 * закруглённый нижний край, плавный переход вниз. Треки уходят под неё и размываются.
 */
@Composable
fun Modifier.glassHeader(bottomRadius: Dp): Modifier {
    val settings = LocalSettings.current
    val accent = LocalAccent.current
    val state = LocalGlass.current
    val liquid = settings.liquidGlass
    val blurOn = liquid && state != null
    val canBlur = blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val main = accent.main
    val soft = accent.soft
    val k = 0.7f + 0.6f * settings.glassIntensity
    val shape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomEnd = bottomRadius, bottomStart = bottomRadius)

    var m: Modifier = this.drawBehind {
        // плавный переход под панелью: тень + фиолетовая подсветка, сходящая на нет
        val fade = 38.dp.toPx()
        drawRect(
            Brush.verticalGradient(
                listOf(LyfeColors.Bg.copy(alpha = 0.55f), main.copy(alpha = 0.10f * k), Color.Transparent),
                startY = size.height, endY = size.height + fade,
            ),
            topLeft = Offset(0f, size.height),
            size = Size(size.width, fade),
        )
    }.clip(shape)
    if (blurOn && state != null) {
        m = m.hazeEffect(state.haze) {
            blurRadius = 30.dp
            noiseFactor = 0f
        }
    }
    return m.drawBehind {
        val w = size.width
        val h = size.height
        if (w <= 1f || h <= 1f) return@drawBehind
        val dp = 1.dp.toPx()
        val rb = min(bottomRadius.toPx(), min(w, h) / 2f)

        // вуаль: тёмная, плотнее сверху
        drawRect(
            Brush.verticalGradient(
                listOf(
                    Color(0xFF1B0E36).copy(alpha = if (canBlur) 0.80f else 0.94f),
                    Color(0xFF140A28).copy(alpha = if (canBlur) 0.62f else 0.88f),
                )
            )
        )
        drawRect(
            Brush.verticalGradient(
                listOf(main.copy(alpha = 0.32f * k), main.copy(alpha = 0.10f * k), main.copy(alpha = 0.24f * k))
            )
        )
        // складки шёлка
        for (f in silkFolds) {
            val c = if (f.light) soft else main
            drawRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, c.copy(alpha = (f.a * k).coerceAtMost(0.5f)), Color.Transparent),
                    start = Offset(f.x * w, 0f),
                    end = Offset((f.x + f.bw) * w, h * f.slope),
                )
            )
        }
        // свечение у левого края и нижний отблеск
        drawRect(
            Brush.radialGradient(
                listOf(soft.copy(alpha = 0.34f * k), Color.Transparent),
                center = Offset(0f, h * 0.45f), radius = w * 0.40f,
            )
        )
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, soft.copy(alpha = 0.18f * k), Color.Transparent),
                startY = h * 0.60f, endY = h * 0.94f,
            )
        )
        // затемнение у самого верха — читаемость статус-бара
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Black.copy(alpha = 0.30f), Color.Transparent),
                startY = 0f, endY = 48.dp.toPx(),
            )
        )
        // кромка по нижнему краю с закруглёнными концами
        drawRoundRect(
            brush = Brush.horizontalGradient(
                0f to soft.copy(alpha = 0.85f),
                0.18f to Color(0xFFD9CCFF).copy(alpha = 0.26f),
                0.50f to soft.copy(alpha = 0.20f),
                0.82f to Color(0xFFD9CCFF).copy(alpha = 0.26f),
                1f to soft.copy(alpha = 0.85f),
            ),
            topLeft = Offset(0f, -rb * 2f),
            size = Size(w, h + rb * 2f),
            cornerRadius = CornerRadius(rb),
            style = Stroke(2.4f * dp),
        )
        // тонкая фиолетовая линия-свечение над нижней кромкой
        drawRoundRect(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, soft.copy(alpha = 0.55f * k), Color.Transparent),
                startX = w * 0.08f, endX = w * 0.92f,
            ),
            topLeft = Offset(w * 0.08f, h - 3.4f * dp),
            size = Size(w * 0.84f, 1.4f * dp),
            cornerRadius = CornerRadius(dp),
        )
    }
}

// ---------------------------------------------------------------------------------------------
//  Размытие и затемнение треков при уходе под панели
// ---------------------------------------------------------------------------------------------

/**
 * Элементы списка плавно размываются и темнеют, когда заходят под верхнюю панель (topPx)
 * или под нижние панели (bottomPx). Размытие — Android 12+, затемнение — везде.
 */
fun Modifier.edgeBlur(state: LazyListState, key: Any, topPx: Float, bottomPx: Float): Modifier =
    this.graphicsLayer {
        val info = state.layoutInfo
        val item = info.visibleItemsInfo.firstOrNull { it.key == key } ?: return@graphicsLayer
        val cy = item.offset + item.size / 2f
        val viewportH = info.viewportSize.height.toFloat()
        val z = 22.dp.toPx()
        var f = 0f
        if (topPx > 0f) f = max(f, ((topPx + z - cy) / (topPx * 0.65f + z)).coerceIn(0f, 1f))
        if (bottomPx > 0f) f = max(f, ((cy - (viewportH - bottomPx - z)) / (bottomPx * 0.65f + z)).coerceIn(0f, 1f))
        if (f > 0.01f) {
            alpha = 1f - 0.6f * f
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val r = f * 14.dp.toPx()
                renderEffect = BlurEffect(r, r, TileMode.Decal)
            }
        }
    }

// ---------------------------------------------------------------------------------------------
//  Кнопки
// ---------------------------------------------------------------------------------------------

/** Пружинящее нажатие без ripple. */
@Composable
fun Modifier.bounceClick(
    onClick: () -> Unit,
    pressedScale: Float = 0.93f,
    enabled: Boolean = true,
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 600f),
        label = "bounce",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Круглая стеклянная кнопка. */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    tint: Color = Color.White,
    glassTint: Color = Color.Unspecified,
) {
    Box(
        modifier = modifier
            .size(size)
            .liquidGlass(size / 2, strength = 0.9f, glow = false, tint = glassTint)
            .bounceClick(onClick, 0.88f),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription, tint = tint, modifier = Modifier.size(iconSize))
    }
}
