package com.lyfestyle.music.ui.screens

import android.content.res.Configuration
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.lyfestyle.music.data.Track
import com.lyfestyle.music.playback.PlayerController
import com.lyfestyle.music.playback.PlayerState
import com.lyfestyle.music.ui.AppViewModel
import com.lyfestyle.music.ui.LocalStrings
import com.lyfestyle.music.ui.components.Artwork
import com.lyfestyle.music.ui.components.GlassIconButton
import com.lyfestyle.music.ui.components.LocalGlass
import com.lyfestyle.music.ui.components.LocalTrackActions
import com.lyfestyle.music.ui.components.LyfeBackground
import com.lyfestyle.music.ui.components.SeekBar
import com.lyfestyle.music.ui.components.TrackInfoDialog
import com.lyfestyle.music.ui.components.artistLabel
import com.lyfestyle.music.ui.components.bounceClick
import com.lyfestyle.music.ui.components.computePalette
import com.lyfestyle.music.ui.components.fmtTime
import com.lyfestyle.music.ui.components.glassSource
import com.lyfestyle.music.ui.components.liquidGlass
import com.lyfestyle.music.ui.components.rememberArtwork
import com.lyfestyle.music.ui.components.rememberGlassState
import com.lyfestyle.music.ui.components.subtitle
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import com.lyfestyle.music.ui.theme.LyfeColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun PlayerScreen(vm: AppViewModel, onClose: () -> Unit) {
    val player = vm.player
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val settings = LocalSettings.current
    val ps by player.state.collectAsState()
    val trackMap by vm.trackMap.collectAsState()
    val favs by vm.store.favorites.collectAsState()
    val track = ps.currentId?.let { trackMap[it] }

    BackHandler(onBack = onClose)

    val small by rememberArtwork(track, 64.dp)
    val pal by produceState(initialValue = accent.main to accent.soft, small, accent) {
        value = withContext(Dispatchers.Default) { computePalette(small?.asAndroidBitmap(), accent.main) }
    }
    val c1 by animateColorAsState(if (settings.dynamicBackground) pal.first else accent.main, tween(800), label = "c1")
    val c2 by animateColorAsState(if (settings.dynamicBackground) pal.second else accent.soft, tween(800), label = "c2")

    val glass = rememberGlassState()
    var showQueue by remember { mutableStateOf(false) }
    var showTimer by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    CompositionLocalProvider(LocalGlass provides glass) {
        Box(Modifier.fillMaxSize().background(LyfeColors.Bg)) {
            Box(Modifier.fillMaxSize().glassSource(glass)) {
                PlayerBackground(c1, c2, small, settings.dynamicBackground)
            }
            if (track != null) {
                if (landscape) {
                    Row(
                        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(28.dp),
                    ) {
                        BoxWithConstraints(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                            val side = minOf(maxWidth, maxHeight * 0.92f)
                            PlayerArtwork(trackMap, ps, player, c1, Modifier.size(side))
                        }
                        Column(
                            Modifier.weight(1.1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.Center,
                        ) {
                            PlayerTopBar(vm, track, favs.contains(track.id), onClose) { showInfo = true }
                            Spacer(Modifier.height(8.dp))
                            PlayerPanel(vm, ps, track, favs.contains(track.id), { showQueue = true }, { showTimer = true })
                        }
                    }
                } else {
                    Column(
                        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp),
                    ) {
                        PlayerTopBar(vm, track, favs.contains(track.id), onClose) { showInfo = true }
                        Spacer(Modifier.height(16.dp))
                        PlayerArtwork(trackMap, ps, player, c1, Modifier.fillMaxWidth().padding(horizontal = 2.dp).aspectRatio1())
                        Spacer(Modifier.height(30.dp))
                        PlayerPanel(vm, ps, track, favs.contains(track.id), { showQueue = true }, { showTimer = true })
                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
        }
    }

    if (showQueue) QueueSheet(vm) { showQueue = false }
    if (showInfo && track != null) TrackInfoDialog(track) { showInfo = false }
    if (showTimer) SleepTimerDialog(player, ps) { showTimer = false }
}

private fun Modifier.aspectRatio1(): Modifier = this.then(Modifier.aspectRatio(1f))

@Composable
private fun PlayerBackground(c1: Color, c2: Color, art: ImageBitmap?, dynamic: Boolean) {
    Box(Modifier.fillMaxSize()) {
        LyfeBackground(c1, c2, strength = if (dynamic) 1.75f else 1f)
        if (dynamic && art != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Image(art, null, Modifier.fillMaxSize().blur(60.dp).alpha(0.55f), contentScale = ContentScale.Crop)
        }
    }
}

@Composable
private fun PlayerTopBar(vm: AppViewModel, track: Track, favorite: Boolean, onClose: () -> Unit, onInfo: () -> Unit) {
    val s = LocalStrings.current
    val actions = LocalTrackActions.current
    var menu by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val rev = com.lyfestyle.music.ui.components.ArtworkLoader.revision.intValue
    val hasCustom = remember(menu, rev) { com.lyfestyle.music.data.CoverStore.exists(ctx, track.id) }
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        GlassIconButton(Icons.Rounded.KeyboardArrowDown, s.close, onClose, size = 46.dp, iconSize = 28.dp)
        Spacer(Modifier.weight(1f))
        Box {
            GlassIconButton(Icons.Rounded.MoreHoriz, s.more, { menu = true }, size = 46.dp)
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(s.menuInfo) }, leadingIcon = { Icon(Icons.Rounded.Info, null) },
                    onClick = { menu = false; onInfo() },
                )
                DropdownMenuItem(
                    text = { Text(s.menuAddPlaylist) }, leadingIcon = { Icon(Icons.Rounded.PlaylistAdd, null) },
                    onClick = { menu = false; actions.addToPlaylist(track) },
                )
                DropdownMenuItem(
                    text = { Text(if (favorite) s.menuUnfav else s.menuFav) },
                    leadingIcon = { Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null) },
                    onClick = { menu = false; actions.toggleFavorite(track) },
                )
                DropdownMenuItem(
                    text = { Text(s.changeCover) }, leadingIcon = { Icon(Icons.Rounded.Image, null) },
                    onClick = { menu = false; actions.changeCover(track) },
                )
                if (hasCustom) {
                    DropdownMenuItem(
                        text = { Text(s.resetCover) }, leadingIcon = { Icon(Icons.Rounded.Restore, null) },
                        onClick = { menu = false; actions.resetCover(track) },
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerArtwork(
    trackMap: Map<Long, Track>,
    ps: PlayerState,
    player: PlayerController,
    glow: Color,
    modifier: Modifier,
) {
    val scale by animateFloatAsState(
        targetValue = if (ps.isPlaying) 1f else 0.88f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 220f),
        label = "artScale",
    )
    val dir = if (ps.direction >= 0) 1 else -1
    Box(
        modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .pointerInput(Unit) {
                var dx = 0f
                detectHorizontalDragGestures(
                    onDragStart = { dx = 0f },
                    onDragEnd = {
                        if (dx > 140f) player.previous() else if (dx < -140f) player.next()
                    },
                    onHorizontalDrag = { _, d -> dx += d },
                )
            }
    ) {
        AnimatedContent(
            targetState = ps.currentId,
            transitionSpec = {
                (slideInHorizontally(tween(450)) { it * dir / 2 } + fadeIn(tween(450)) + scaleIn(tween(450), initialScale = 0.9f)) togetherWith
                    (slideOutHorizontally(tween(450)) { -it * dir / 2 } + fadeOut(tween(300)) + scaleOut(tween(450), targetScale = 0.9f))
            },
            label = "artSwitch",
            modifier = Modifier.fillMaxSize(),
        ) { id ->
            val shape = RoundedCornerShape(28.dp)
            Artwork(
                track = id?.let { trackMap[it] },
                modifier = Modifier
                    .fillMaxSize()
                    .shadow(28.dp, shape, ambientColor = glow, spotColor = glow),
                radius = 28.dp,
                decodeSize = 512.dp,
            )
        }
    }
}

@Composable
private fun PlayerPanel(
    vm: AppViewModel,
    ps: PlayerState,
    track: Track,
    favorite: Boolean,
    onQueue: () -> Unit,
    onTimer: () -> Unit,
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val player = vm.player
    val actions = LocalTrackActions.current

    // Название, исполнитель, избранное
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                track.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, modifier = Modifier.basicMarquee(),
            )
            Text(
                track.artistLabel(s), color = accent.soft, fontSize = 18.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        GlassIconButton(
            icon = if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            contentDescription = if (favorite) s.menuUnfav else s.menuFav,
            onClick = { actions.toggleFavorite(track) },
            size = 48.dp,
            tint = if (favorite) accent.soft else Color.White,
        )
    }
    Spacer(Modifier.height(14.dp))

    // Прогресс
    SeekSection(player, track, ps)
    Spacer(Modifier.height(18.dp))

    // Управление
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TransportIcon(Icons.Rounded.Shuffle, s.shuffle, ps.shuffle, 26.dp) { player.toggleShuffle() }
        TransportIcon(Icons.Rounded.SkipPrevious, null, false, 44.dp, tintOff = Color.White) { player.previous() }
        PlayPauseButton(ps.isPlaying) { player.togglePlay() }
        TransportIcon(Icons.Rounded.SkipNext, null, false, 44.dp, tintOff = Color.White) { player.next() }
        TransportIcon(
            if (ps.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
            null, ps.repeatMode != Player.REPEAT_MODE_OFF, 26.dp,
        ) { player.cycleRepeat() }
    }
    Spacer(Modifier.height(26.dp))

    // Нижний ряд: таймер сна, в плейлист, очередь
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        BottomIcon(Icons.Rounded.Timer, s.sleepTimer, ps.sleepEndsAt > 0L, onTimer)
        BottomIcon(Icons.Rounded.PlaylistAdd, s.menuAddPlaylist, false) { actions.addToPlaylist(track) }
        BottomIcon(Icons.Rounded.QueueMusic, s.queue, false, onQueue)
    }
}

@Composable
private fun SeekSection(player: PlayerController, track: Track, ps: PlayerState) {
    val accent = LocalAccent.current
    val position by player.position.collectAsState()
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = if (ps.durationMs > 0) ps.durationMs else track.durationMs
    val d = drag
    val frac = d ?: if (dur > 0) (position.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val shown = if (d != null) (d * dur).toLong() else position
    SeekBar(
        fraction = frac,
        onChange = { drag = it },
        onFinished = { f ->
            player.seekTo((f * dur).toLong())
            drag = null
        },
        activeColor = accent.main,
        trackColor = Color.White.copy(alpha = 0.14f),
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(fmtTime(shown), color = LyfeColors.TextSecondary, fontSize = 13.sp)
        Text("-" + fmtTime((dur - shown).coerceAtLeast(0L)), color = LyfeColors.TextSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun TransportIcon(
    icon: ImageVector,
    desc: String?,
    active: Boolean,
    iconSize: androidx.compose.ui.unit.Dp,
    tintOff: Color = LyfeColors.TextSecondary,
    onClick: () -> Unit,
) {
    val accent = LocalAccent.current
    Box(Modifier.size(54.dp).bounceClick(onClick, 0.82f), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = if (active) accent.main else tintOff, modifier = Modifier.size(iconSize))
    }
}

@Composable
private fun PlayPauseButton(playing: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(84.dp).liquidGlass(42.dp, strength = 0.9f).bounceClick(onClick, 0.9f),
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(targetState = playing, animationSpec = tween(180), label = "playPause") { p ->
            Icon(
                if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                null, tint = Color.White, modifier = Modifier.size(46.dp),
            )
        }
    }
}

@Composable
private fun BottomIcon(icon: ImageVector, desc: String, active: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Box(Modifier.size(48.dp).bounceClick(onClick, 0.85f), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = if (active) accent.soft else accent.main, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun SleepTimerDialog(player: PlayerController, ps: PlayerState, onDismiss: () -> Unit) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LyfeColors.SurfaceHigh,
        title = { Text(s.sleepTimer, color = Color.White) },
        text = {
            Column {
                if (ps.sleepEndsAt > 0L) {
                    val left = (((ps.sleepEndsAt - System.currentTimeMillis()) / 60000L).toInt() + 1).coerceAtLeast(1)
                    Text(s.sleepActive(left), color = accent.soft, modifier = Modifier.padding(bottom = 8.dp))
                }
                listOf(15, 30, 45, 60).forEach { m ->
                    Text(
                        s.minutesN(m), color = Color.White, fontSize = 18.sp,
                        modifier = Modifier.fillMaxWidth()
                            .clickable { player.setSleepTimer(m); onDismiss() }
                            .padding(vertical = 12.dp),
                    )
                }
            }
        },
        confirmButton = {
            if (ps.sleepEndsAt > 0L) {
                TextButton(onClick = { player.setSleepTimer(0); onDismiss() }) { Text(s.sleepOff, color = accent.soft) }
            } else {
                TextButton(onClick = onDismiss) { Text(s.close, color = accent.soft) }
            }
        },
    )
}

@Composable
private fun QueueSheet(vm: AppViewModel, onDismiss: () -> Unit) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val ps by vm.player.state.collectAsState()
    val trackMap by vm.trackMap.collectAsState()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Color(0xFF120C1C),
        contentColor = Color.White,
    ) {
        Text(
            s.queue + " · " + ps.queue.size,
            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 22.dp, bottom = 8.dp),
        )
        if (ps.queue.isEmpty()) {
            Text(s.queueEmpty, color = LyfeColors.TextSecondary, modifier = Modifier.padding(22.dp))
        } else {
            val listState = rememberLazyListState(initialFirstVisibleItemIndex = (ps.currentIndex - 1).coerceAtLeast(0))
            LazyColumn(state = listState, modifier = Modifier.heightIn(max = 520.dp)) {
                itemsIndexed(ps.queue) { i, id ->
                    val t = trackMap[id]
                    if (t != null) {
                        val current = i == ps.currentIndex
                        var menu by remember { mutableStateOf(false) }
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { vm.player.seekToQueueIndex(i) }
                                .padding(start = 18.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Artwork(t, Modifier.size(48.dp), radius = 12.dp, decodeSize = 48.dp)
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(
                                    t.title, color = if (current) accent.soft else Color.White, fontSize = 16.sp,
                                    fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                                Text(t.subtitle(s), color = LyfeColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Box {
                                Box(Modifier.size(44.dp).bounceClick({ menu = true }, 0.85f), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.MoreVert, s.more, tint = accent.main)
                                }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(
                                        text = { Text(s.moveUp) },
                                        onClick = { menu = false; vm.player.moveInQueue(i, i - 1) },
                                    )
                                    DropdownMenuItem(
                                        text = { Text(s.moveDown) },
                                        onClick = { menu = false; vm.player.moveInQueue(i, i + 1) },
                                    )
                                    DropdownMenuItem(
                                        text = { Text(s.remove) },
                                        leadingIcon = { Icon(Icons.Rounded.Close, null) },
                                        onClick = { menu = false; vm.player.removeFromQueue(i) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
