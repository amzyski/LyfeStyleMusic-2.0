package com.lyfestyle.music.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.animateColorAsState
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.lyfestyle.music.data.Track
import com.lyfestyle.music.ui.components.Artwork
import com.lyfestyle.music.ui.components.LocalGlass
import com.lyfestyle.music.ui.components.LocalTrackActions
import com.lyfestyle.music.ui.components.LyfeBackground
import com.lyfestyle.music.ui.components.NameInputDialog
import com.lyfestyle.music.ui.components.PlaylistPickerDialog
import com.lyfestyle.music.ui.components.SeekBar
import com.lyfestyle.music.ui.components.TrackActions
import com.lyfestyle.music.ui.components.artistLabel
import com.lyfestyle.music.ui.components.glassHeader
import com.lyfestyle.music.ui.components.bounceClick
import com.lyfestyle.music.ui.components.glassLens
import com.lyfestyle.music.ui.components.glassSource
import com.lyfestyle.music.ui.components.liquidGlass
import com.lyfestyle.music.ui.components.rememberGlassState
import com.lyfestyle.music.ui.screens.LibraryScreen
import com.lyfestyle.music.ui.screens.LibraryTopBar
import com.lyfestyle.music.ui.screens.PlayerScreen
import com.lyfestyle.music.ui.screens.PlaylistsScreen
import com.lyfestyle.music.ui.screens.ProfileScreen
import com.lyfestyle.music.ui.screens.SearchScreen
import com.lyfestyle.music.ui.theme.Accents
import com.lyfestyle.music.ui.theme.LocalAccent
import com.lyfestyle.music.ui.theme.LocalSettings
import com.lyfestyle.music.ui.theme.LyfeColors
import com.lyfestyle.music.ui.theme.LyfeTheme
import androidx.compose.ui.graphics.vector.ImageVector

@Composable
fun AppRoot(vm: AppViewModel) {
    val settings by vm.store.settings.collectAsState()
    val accent = Accents[settings.accentIndex.coerceIn(Accents.indices)]
    val strings = remember(settings.language) { Strings(settings.language == "ru") }
    LyfeTheme(accent) {
        CompositionLocalProvider(
            LocalSettings provides settings,
            LocalAccent provides accent,
            LocalStrings provides strings,
        ) {
            RootContent(vm)
        }
    }
}

@Composable
private fun RootContent(vm: AppViewModel) {
    val context = LocalContext.current
    val s = LocalStrings.current
    val accent = LocalAccent.current

    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    fun hasAudio() = ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasAudio()) }
    var asked by rememberSaveable { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudio()
        if (granted) vm.refresh()
    }
    fun requestPerms() {
        asked = true
        val list = mutableListOf(audioPerm)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        launcher.launch(list.toTypedArray())
    }
    LaunchedEffect(Unit) { if (!granted && !asked) requestPerms() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasAudio()
        if (granted) vm.refresh()
    }

    if (!granted) {
        PermissionScreen(
            onAllow = { requestPerms() },
            onSettings = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            },
            showSettings = asked,
        )
        return
    }

    var tab by rememberSaveable { mutableStateOf(0) }
    var playerOpen by rememberSaveable { mutableStateOf(false) }
    var pickerTrack by remember { mutableStateOf<Track?>(null) }
    val libraryState = rememberLazyListState()
    var coverTarget by remember { mutableStateOf<Track?>(null) }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val tr = coverTarget
        if (uri != null && tr != null) {
            vm.setCover(tr, uri)
            Toast.makeText(context, s.coverUpdated, Toast.LENGTH_SHORT).show()
        }
        coverTarget = null
    }
    val glass = rememberGlassState()

    val ps by vm.player.state.collectAsState()
    val trackMap by vm.trackMap.collectAsState()
    val playlists by vm.store.playlists.collectAsState()
    val currentTrack = ps.currentId?.let { trackMap[it] }

    BackHandler(enabled = tab != 0 && !playerOpen) { tab = 0 }

    val actions = remember(vm, s) {
        fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        TrackActions(
            playNext = { vm.player.playNext(it); toast(s.playNextDone) },
            addToQueue = { vm.player.addToQueue(it); toast(s.addedToQueue) },
            addToPlaylist = { pickerTrack = it },
            toggleFavorite = { vm.store.toggleFavorite(it.id) },
            changeCover = {
                coverTarget = it
                coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            resetCover = { vm.resetCover(it) },
        )
    }

    var bottomBarHeight by remember { mutableStateOf(0.dp) }
    var topBarHeight by remember { mutableStateOf(0.dp) }
    val density = LocalDensity.current

    CompositionLocalProvider(LocalGlass provides glass, LocalTrackActions provides actions) {
        Box(Modifier.fillMaxSize().background(LyfeColors.Bg)) {
            Box(Modifier.fillMaxSize().glassSource(glass)) {
                LyfeBackground(accent.main.copy(alpha = 0.8f), accent.main.copy(alpha = 0.6f))
                Crossfade(targetState = tab, animationSpec = tween(220), label = "tabs") { t ->
                    val pad = bottomBarHeight + 12.dp
                    when (t) {
                        0 -> LibraryScreen(vm, libraryState, topBarHeight + 4.dp, pad)
                        1 -> PlaylistsScreen(vm, pad)
                        2 -> ProfileScreen(vm, pad)
                        else -> SearchScreen(vm, pad)
                    }
                }
            }

            // Мягкое затемнение под нижними панелями
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(bottomBarHeight + 26.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, LyfeColors.Bg.copy(alpha = 0.82f))))
            )
            // Верхняя стеклянная панель библиотеки
            if (tab == 0) {
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .onSizeChanged { topBarHeight = with(density) { it.height.toDp() } }
                        .glassHeader(30.dp)
                ) {
                    LibraryTopBar(vm, onOpenProfile = { tab = 2 })
                }
            }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .onSizeChanged { bottomBarHeight = with(density) { it.height.toDp() } }
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AnimatedVisibility(
                    visible = currentTrack != null,
                    enter = slideInVertically(tween(350)) { it } + fadeIn(),
                    exit = slideOutVertically(tween(250)) { it } + fadeOut(),
                ) {
                    currentTrack?.let { t ->
                        MiniPlayer(
                            track = t,
                            isPlaying = ps.isPlaying,
                            vm = vm,
                            fallbackDuration = ps.durationMs,
                            onOpen = { playerOpen = true },
                        )
                    }
                }
                GlassNavBar(selected = tab, onSelect = { tab = it })
            }

            AnimatedVisibility(
                visible = playerOpen && currentTrack != null,
                enter = slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                exit = slideOutVertically(tween(320, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(250)),
            ) {
                PlayerScreen(vm = vm, onClose = { playerOpen = false })
            }
        }

        pickerTrack?.let { t ->
            PlaylistPickerDialog(
                playlists = playlists,
                onPick = { id ->
                    vm.store.addTracks(id, listOf(t.id))
                    val name = playlists.firstOrNull { it.id == id }?.name ?: ""
                    Toast.makeText(context, s.addedToPlaylist(name), Toast.LENGTH_SHORT).show()
                    pickerTrack = null
                },
                onCreate = { name ->
                    vm.store.createPlaylist(name, listOf(t.id))
                    Toast.makeText(context, s.addedToPlaylist(name), Toast.LENGTH_SHORT).show()
                    pickerTrack = null
                },
                onDismiss = { pickerTrack = null },
            )
        }
    }
}


// ---------------- Нижняя навигация (Liquid Glass) ----------------

private class NavItem(val icon: ImageVector, val label: String)

@Composable
fun GlassNavBar(selected: Int, onSelect: (Int) -> Unit) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val items = listOf(
        NavItem(Icons.Rounded.LibraryMusic, s.library),
        NavItem(Icons.Rounded.Album, s.playlists),
        NavItem(Icons.Rounded.Person, s.profile),
        NavItem(Icons.Rounded.Search, s.search),
    )
    val inactive = Color(0xFFB4A9D2)
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .height(61.dp)
            .liquidGlass(30.5.dp)
    ) {
        val itemW = maxWidth / items.size
        val x by animateDpAsState(itemW * selected, spring(dampingRatio = 0.7f, stiffness = 320f), label = "lens")
        // «Линза» под активной вкладкой
        Box(
            Modifier
                .offset(x = x)
                .width(itemW)
                .fillMaxHeight()
                .padding(3.dp)
                .glassLens(27.dp)
        )
        Row(Modifier.fillMaxSize()) {
            items.forEachIndexed { i, item ->
                val active = i == selected
                val color by animateColorAsState(
                    if (active) accent.soft else inactive, tween(250), label = "navColor"
                )
                val disc by animateFloatAsState(if (active) 1f else 0f, tween(250), label = "disc")
                val iconSize by animateDpAsState(if (active) 19.dp else 23.dp, tween(250), label = "iconSize")
                Column(
                    Modifier.weight(1f).fillMaxHeight().bounceClick({ onSelect(i) }, 0.9f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .size(31.dp)
                            .drawBehind {
                                if (disc > 0.01f) {
                                    drawCircle(
                                        Brush.radialGradient(
                                            listOf(accent.main.copy(alpha = 0.40f * disc), Color.Transparent),
                                            center = Offset(size.width / 2, size.height / 2),
                                            radius = size.width * 0.95f,
                                        )
                                    )
                                    drawCircle(accent.main.copy(alpha = 0.92f * disc), radius = size.width / 2)
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(item.icon, item.label, tint = color, modifier = Modifier.size(iconSize))
                    }
                    Text(
                        item.label, color = color, fontSize = 10.5.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

// ---------------- Мини-плеер ----------------

@Composable
fun MiniPlayer(
    track: Track,
    isPlaying: Boolean,
    vm: AppViewModel,
    fallbackDuration: Long,
    onOpen: () -> Unit,
) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    val position by vm.player.position.collectAsState()
    val dur = if (fallbackDuration > 0) fallbackDuration else track.durationMs
    val frac = if (dur > 0) (position.toFloat() / dur).coerceIn(0f, 1f) else 0f

    Box(
        Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth()
            .height(54.dp)
            .liquidGlass(27.dp)
            .bounceClick(onOpen, 0.98f)
    ) {
        Row(
            Modifier.fillMaxSize().padding(start = 7.dp, end = 4.dp, bottom = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Artwork(track, Modifier.size(40.dp), radius = 12.dp, decodeSize = 40.dp, fade = true)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(track.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artistLabel(s), color = accent.soft.copy(alpha = 0.85f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.size(40.dp).bounceClick({ vm.player.togglePlay() }, 0.85f), contentAlignment = Alignment.Center) {
                Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(29.dp))
            }
            Box(Modifier.size(40.dp).bounceClick({ vm.player.next() }, 0.85f), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipNext, null, tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }
        // Тонкая полоса прогресса с точкой
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 22.dp, vertical = 4.dp)
                .fillMaxWidth()
                .height(6.dp)
                .drawBehind {
                    val cy = size.height / 2f
                    val th = 2.dp.toPx()
                    val x = (size.width * frac).coerceIn(0f, size.width)
                    drawLine(Color.White.copy(alpha = 0.13f), Offset(0f, cy), Offset(size.width, cy), th, androidx.compose.ui.graphics.StrokeCap.Round)
                    if (x > 0f) {
                        drawLine(accent.main, Offset(0f, cy), Offset(x, cy), th, androidx.compose.ui.graphics.StrokeCap.Round)
                    }
                    drawCircle(accent.main.copy(alpha = 0.30f), 3.4.dp.toPx(), Offset(x.coerceAtLeast(3.dp.toPx()), cy))
                    drawCircle(accent.soft, 2.2.dp.toPx(), Offset(x.coerceAtLeast(3.dp.toPx()), cy))
                }
        )
    }
}

// ---------------- Экран запроса разрешения ----------------

@Composable
private fun PermissionScreen(onAllow: () -> Unit, onSettings: () -> Unit, showSettings: Boolean) {
    val s = LocalStrings.current
    val accent = LocalAccent.current
    Box(Modifier.fillMaxSize()) {
        LyfeBackground(accent.main, accent.main)
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            androidx.compose.foundation.Image(
                androidx.compose.ui.res.painterResource(com.lyfestyle.music.R.drawable.ic_brand), null,
                Modifier.size(110.dp),
            )
            Spacer(Modifier.height(24.dp))
            Text(s.permTitle, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(s.permBody, color = LyfeColors.TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(32.dp))
            Box(
                Modifier.height(54.dp).fillMaxWidth().liquidGlass(27.dp, backdrop = false).bounceClick(onAllow),
                contentAlignment = Alignment.Center,
            ) { Text(s.permAllow, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            if (showSettings) {
                Spacer(Modifier.height(14.dp))
                Box(Modifier.height(44.dp).bounceClick(onSettings), contentAlignment = Alignment.Center) {
                    Text(s.permSettings, color = accent.soft, fontSize = 15.sp)
                }
            }
        }
    }
}
