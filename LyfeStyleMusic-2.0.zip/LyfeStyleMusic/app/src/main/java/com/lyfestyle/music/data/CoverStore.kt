package com.lyfestyle.music.data

import android.content.Context
import java.io.File

/** Пользовательские обложки песен: filesDir/covers/<trackId>.jpg */
object CoverStore {
    fun file(ctx: Context, trackId: Long): File = File(File(ctx.filesDir, "covers"), "$trackId.jpg")
    fun exists(ctx: Context, trackId: Long): Boolean = file(ctx, trackId).exists()
}
