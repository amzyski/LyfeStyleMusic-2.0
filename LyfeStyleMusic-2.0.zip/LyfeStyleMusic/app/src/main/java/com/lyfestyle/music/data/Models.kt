package com.lyfestyle.music.data

import android.content.ContentUris
import android.net.Uri
import java.util.Locale

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val uri: Uri,
    val dateAdded: Long,
) {
    /** URI обложки альбома из MediaStore (используется для уведомления). */
    val artworkUri: Uri
        get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
}

data class Playlist(
    val id: String,
    val name: String,
    val trackIds: List<Long>,
    val createdAt: Long,
)

fun defaultLanguage(): String = if (Locale.getDefault().language == "ru") "ru" else "en"

data class AppSettings(
    val language: String = defaultLanguage(),
    val liquidGlass: Boolean = true,
    val glassIntensity: Float = 0.6f,
    val accentIndex: Int = 0,
    val dynamicBackground: Boolean = true,
    val userName: String = "",
    val avatarVersion: Long = 0L,
)
