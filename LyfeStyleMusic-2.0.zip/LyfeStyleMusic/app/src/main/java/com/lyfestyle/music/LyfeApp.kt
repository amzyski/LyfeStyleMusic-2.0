package com.lyfestyle.music

import android.app.Application
import com.lyfestyle.music.data.LocalStore
import com.lyfestyle.music.playback.PlayerController

class LyfeApp : Application() {
    lateinit var store: LocalStore
        private set
    lateinit var player: PlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        store = LocalStore(this)
        player = PlayerController(this, store)
        player.connect()
    }
}
