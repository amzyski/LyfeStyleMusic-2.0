# LyfeStyle Music 2.0

Локальный музыкальный плеер для Android в стиле Liquid Glass: тёмный интерфейс, фиолетовые акценты,
стеклянная нижняя навигация, мини-плеер и полноэкранный плеер с динамическим фоном из обложки.

Kotlin · Jetpack Compose · Media3 (ExoPlayer + MediaSession) · MediaStore. Без серверов, рекламы, регистрации и онлайн-каталогов.

## Возможности
- Библиотека всех аудиофайлов устройства (MediaStore), обложки, меню действий, обновление, «перемешать всё».
- Плеер: обложка, размытый фон по цветам обложки, избранное, прогресс, перемотка, shuffle/repeat, громкость, очередь (перестановка/удаление), таймер сна, свайп обложки.
- Мини-плеер над навигацией, фоновое воспроизведение, управление из уведомления и с экрана блокировки.
- Плейлисты (создание, переименование, удаление, добавление/удаление песен, порядок), хранятся локально; «Избранное».
- Поиск по названию, исполнителю и альбому — по мере ввода.
- Профиль: аватар (системный выбор фото), имя, статистика, топ треков, язык RU/EN, переключатель Liquid Glass, интенсивность стекла, акцентный цвет, фон из обложки.
- Вкладки: **Библиотека · Плейлисты · Профиль · Поиск**.

## Liquid Glass
Фон за панелью записывается в `GraphicsLayer`, каждая стеклянная панель рисует из него свой фрагмент с размытием
(`RenderEffect`, Android 12+), поверх — тонировка, зеркальный блик, светлый контур, цветная рефракционная кайма и свечение.
На Android 8–11 размытия нет — панели получают более плотную тонировку. В настройках стекло можно выключить.

## Сборка
Требуется JDK 17 и Android SDK (compileSdk 35). minSdk 26, target 35.

**GitHub Actions (рекомендуется):** загрузите проект в репозиторий → вкладка *Actions* → *Build APK* →
артефакты `LyfeStyleMusic-2.0-release` / `-debug` (APK). Workflow не требует wrapper-а: он сам ставит Gradle 8.9.

**Локально:**
```
gradle wrapper --gradle-version 8.9   # один раз — создаст gradle/wrapper/gradle-wrapper.jar
./gradlew assembleRelease             # app/build/outputs/apk/release/
./gradlew assembleDebug
```
Либо откройте папку в Android Studio (Ladybug+) и нажмите Run.
Release-сборка подписана debug-ключом (для быстрой установки); для публикации задайте свой keystore в `app/build.gradle.kts`.

## Обновление приложения без переустановки
Все сборки (debug и release) подписываются одним и тем же ключом `app/lyfestyle.keystore`, а `versionCode`
растёт с номером запуска GitHub Actions. Поэтому новый APK ставится поверх старого, данные сохраняются.
Если на телефоне стоит версия, собранная раньше с другим ключом, её нужно один раз удалить.
Пароль от ключа лежит в `app/build.gradle.kts` — для личного проекта это нормально; для публикации
сделайте свой ключ и не храните его в репозитории.

## Структура
```
app/src/main/java/com/lyfestyle/music/
  data/       Track, MusicRepository (MediaStore), LocalStore (плейлисты, настройки, статистика)
  playback/   PlaybackService (Media3 MediaSessionService), PlayerController (MediaController)
  ui/         AppRoot, AppViewModel, Strings (RU/EN), theme/
  ui/components/  Glass (Liquid Glass), Artwork, Common
  ui/screens/     Library, Playlists, Search, Profile, Player
```

## Разрешения
`READ_MEDIA_AUDIO` (Android 13+) / `READ_EXTERNAL_STORAGE` (до 12), `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `WAKE_LOCK`.
